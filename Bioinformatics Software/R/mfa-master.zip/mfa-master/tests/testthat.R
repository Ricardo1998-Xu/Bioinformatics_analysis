library(testthat)
library(mfa)

test_check("mfa")
