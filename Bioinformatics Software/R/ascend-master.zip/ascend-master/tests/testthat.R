library(testthat)
library(ascend)

test_check("ascend")
