#' ascend A package for the quality control and analysis of Single Cell RNA-sequencing data.
#'
#' This package ....
#' 
#' @docType package
#' @name ascend
NULL