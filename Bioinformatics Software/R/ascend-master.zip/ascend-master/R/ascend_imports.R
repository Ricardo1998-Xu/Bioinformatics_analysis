#' @import methods
#' @import RcppArmadillo
#' @import SummarizedExperiment
#' @import SingleCellExperiment
#' @useDynLib ascend
#' @importFrom Rcpp sourceCpp
NULL
