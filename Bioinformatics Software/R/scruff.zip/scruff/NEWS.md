# scruff 1.19.1
* Refactored parallel prcessing using functions in parallelly and parallel

# scruff 1.10.1

* Fixed bugs related to using new readGFF function
* Added a `NEWS.md` file to track changes to the package.
