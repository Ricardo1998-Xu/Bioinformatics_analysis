library(testthat)
library(netSmooth)

test_check("netSmooth")
