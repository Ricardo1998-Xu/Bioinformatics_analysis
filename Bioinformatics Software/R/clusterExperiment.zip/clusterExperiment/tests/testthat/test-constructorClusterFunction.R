context("Constructor")


test_that("`clusterFunction` constructor works", {
       
 })