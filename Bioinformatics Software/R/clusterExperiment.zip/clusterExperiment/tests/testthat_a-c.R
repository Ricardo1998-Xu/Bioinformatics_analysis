library(testthat)
test_check("clusterExperiment",filter = "^[A-Ca-c]")
