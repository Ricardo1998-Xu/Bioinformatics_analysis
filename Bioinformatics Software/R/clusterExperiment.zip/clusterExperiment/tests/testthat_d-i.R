library(testthat)
test_check("clusterExperiment",filter = "^[D-Id-i]")
