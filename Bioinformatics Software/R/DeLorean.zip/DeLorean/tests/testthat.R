library(testthat)
library(DeLorean)

test_check("DeLorean")
