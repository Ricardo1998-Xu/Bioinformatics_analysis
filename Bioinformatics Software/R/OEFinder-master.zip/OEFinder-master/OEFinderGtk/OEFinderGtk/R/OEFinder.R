#' @title A graphical interface to identify ordering effect genes
#' @usage OEFinder()
#' @author Ning Leng
#' @details 
#' one sided p value from
#' http://www.montefiore.ulg.ac.be/~kvansteen/GBIO0009-1/ac20092010/Class8/Using%20R%20for%20linear%20regression.pdf
#' @return a vector of OE genes; cleaned/adjusted expression data 




OEFinder<-function(){
library(RGtk2)
library(gdata)
# Create window
window = gtkWindow()
# Add title
gtkWidgetModifyBg(window,state="visible",color="peachpuff")
window["title"] = "Detect Ordering Effects"
frame = gtkFrameNew("")

window$add(frame)
# Create vertical container for file name entry
vbox = gtkVBoxNew(FALSE, 20)
vbox$setBorderWidth(22)
frame$add(vbox)
# Add horizontal container for every widget line
hbox = gtkHBoxNew(FALSE, 40)
vbox$packStart(hbox, FALSE, FALSE, 0)
l1= gtkLabelNewWithMnemonic("")
l1$setMarkup("<span font_desc=\"15.0\">File name (support .csv, .xls, .txt, .tab)</span>")
hbox$packStart(l1,FALSE,FALSE,0)
# Add entry in the second column; named "filename"
filename = gtkEntryNew()
filename$setSizeRequest(350,23)
#gtkEntrySetHasFrame(filename,F)
l1$setMnemonicWidget(filename)
hbox$packStart(filename,FALSE,FALSE,0)

open_cb=function(widget, Win=window, fileN=filename){
dia <- gtkFileChooserDialog("Choose a Input file", Win, "open",
"gtk-cancel", GtkResponseType["cancel"], "gtk-open",
GtkResponseType["accept"])
if (dia$run() == GtkResponseType["accept"]) {
	choosename <- dia$getFilename()
	fileN$setText(choosename)
}
dia$destroy()
}

the.buttonsIn = gtkHButtonBoxNew()
the.buttonsIn$setBorderWidth(2)
hbox$add(the.buttonsIn)
the.buttonsIn$setLayout("spread")
the.buttonsIn$setSpacing(6)
buttonOKIn = gtkButtonNewFromStock("gtk-open")
gSignalConnect(buttonOKIn, "clicked", open_cb)
the.buttonsIn$packStart(buttonOKIn,fill=F)

################################ Grouping File ####################################


hbox = gtkHBoxNew(FALSE,20)
vbox$packStart(hbox, FALSE, FALSE, 0)

label = gtkLabelNewWithMnemonic("Grouping vector file name (if not specified, adjacent cells will be grouped together;	
support .csv, .xls, .txt, .tab)")
label$setMarkup("<span font_desc=\"15.0\">
Grouping vector file name (if not specified, adjacent cells 
will be grouped together; support .csv, .xls, .txt, .tab)</span>")
hbox$packStart(label,FALSE,FALSE,0)
GroupVector = gtkEntryNew()
GroupVector$setText("")
GroupVector$setSizeRequest(350,23)
label$setMnemonicWidget(GroupVector)
hbox$packStart(GroupVector,FALSE,FALSE,0)

open_cb_Group=function(widget, Win=window, fileN=GroupVector){
dia <- gtkFileChooserDialog("Choose a Input file", Win, "open",
"gtk-cancel", GtkResponseType["cancel"], "gtk-open",
GtkResponseType["accept"])
if (dia$run() == GtkResponseType["accept"]) {
	choosename <- dia$getFilename()
	fileN$setText(choosename)
}
dia$destroy()
}

the.buttonsGroup = gtkHButtonBoxNew()
the.buttonsGroup$setBorderWidth(2)
hbox$add(the.buttonsGroup)
the.buttonsGroup$setLayout("spread")
the.buttonsGroup$setSpacing(6)
buttonOKGroup = gtkButtonNewFromStock("gtk-open")
gSignalConnect(buttonOKGroup, "clicked", open_cb_Group)
the.buttonsGroup$packStart(buttonOKGroup,fill=F)
#########################################################

############################# P value #####################################

hbox = gtkHBoxNew(FALSE,8)
vbox$packStart(hbox, FALSE, FALSE, 0)


label = gtkLabelNewWithMnemonic("")
label$setMarkup("<span font_desc=\"15.0\">p value cutoff </span>")
hbox$packStart(label,FALSE,FALSE,0)
TgtFDR = gtkEntryNew()
TgtFDR$setSizeRequest(100,23)
TgtFDR$setText("0.01")
label$setMnemonicWidget(TgtFDR)
hbox$packStart(TgtFDR,FALSE,FALSE,0)

#hbox = gtkHBoxNew(FALSE,20)
#vbox$packStart(hbox, FALSE, FALSE, 0)

label = gtkLabelNewWithMnemonic("Number of groups (it will be ignored if grouping vector is provided)")
label$setMarkup("<span font_desc=\"15.0\">  				     Number of groups (it will be ignored 
					if grouping vector is provided)</span>")
hbox$packStart(label,FALSE,FALSE,0)
GroupNum = gtkEntryNew()
GroupNum$setText("8")
GroupNum$setSizeRequest(50,23)
label$setMnemonicWidget(GroupNum)
hbox$packStart(GroupNum,FALSE,FALSE,0)

############################## Normalization ####################

hbox = gtkHBoxNew(FALSE,8)
vbox$packStart(hbox, FALSE, FALSE, 0)

label = gtkLabelNewWithMnemonic("Normalization needed?")
label$setMarkup("<span font_desc=\"15.0\">Normalization needed?</span>")
hbox$packStart(label,F,F,0)
#vbox <- gtkVBox(FALSE, 0)
Norm_buttons <- NULL
button <- gtkRadioButton(Norm_buttons, "yes")
hbox$packStart(button,F,F,0)
Norm_buttons <- c(Norm_buttons, button)
button <- gtkRadioButton(Norm_buttons, "no")
hbox$add(button)
Norm_buttons <- c(Norm_buttons, button)


############################## RM or impute ####################

#hbox = gtkHBoxNew(FALSE,8)
#vbox$packStart(hbox, FALSE, FALSE, 0)

label = gtkLabelNewWithMnemonic("Remove OE genes or impute?")
label$setMarkup("<span font_desc=\"15.0\">Remove OE genes or impute?</span>")
hbox$packStart(label,F,F,0)
#vbox <- gtkVBox(FALSE, 0)
RM_buttons <- NULL
button <- gtkRadioButton(RM_buttons, "Remove")
hbox$packStart(button,F,F,0)
RM_buttons <- c(RM_buttons, button)
button <- gtkRadioButton(RM_buttons, "Impute")
hbox$add(button)
RM_buttons <- c(RM_buttons, button)


############################# LOD #####################################

hbox = gtkHBoxNew(FALSE,8)
vbox$packStart(hbox, FALSE, FALSE, 0)


label = gtkLabelNewWithMnemonic("Lower limit of detection (mean)")
label$setMarkup("<span font_desc=\"15.0\">Lower limit of detection (mean) </span>")
hbox$packStart(label,FALSE,FALSE,0)
LOD = gtkEntryNew()
LOD$setSizeRequest(85,23)
LOD$setText("1")
label$setMnemonicWidget(LOD)
hbox$packStart(LOD,FALSE,FALSE,0)


############################# Num Permutation #####################################

#hbox = gtkHBoxNew(FALSE,8)
#vbox$packStart(hbox, FALSE, FALSE, 0)


label = gtkLabelNewWithMnemonic("Num permutation")
label$setMarkup("<span font_desc=\"15.0\">            Num permutation </span>")
hbox$packStart(label,FALSE,FALSE,0)
PermIn = gtkEntryNew()
PermIn$setSizeRequest(50,23)
PermIn$setText("10000")
label$setMnemonicWidget(PermIn)
hbox$packStart(PermIn,FALSE,FALSE,0)

############################# Outdir  #####################################

hbox = gtkHBoxNew(FALSE,8)
vbox$packStart(hbox, FALSE, FALSE, 0)

label = gtkLabelNewWithMnemonic("Output directory (if not specified, input directory will be used)")
label$setMarkup("<span font_desc=\"15.0\">Output directory (if not specified, input directory will be used</span>")
hbox$packStart(label,FALSE,FALSE,0)
Outdir = gtkEntryNew()
Outdir$setSizeRequest(350,23)
Outdir$setText("")
label$setMnemonicWidget(Outdir)
hbox$packStart(Outdir,FALSE,FALSE,0)



############################ Export normalized matrix ####################################
hbox = gtkHBoxNew(FALSE,20)
vbox$packStart(hbox, FALSE, FALSE, 0)

label = gtkLabelNewWithMnemonic("Export file name for the expression matrix? ")
label$setMarkup("<span font_desc=\"15.0\">Export file name for the expression matrix?  </span>")
hbox$packStart(label,FALSE,FALSE,0)
exNormFileName = gtkEntryNew()
exNormFileName$setText("normalized")
exNormFileName$setSizeRequest(200,23)
hbox$packStart(exNormFileName,FALSE,FALSE,0)
label$setMnemonicWidget(exNormFileName)
label = gtkLabel(".csv")
label$setMarkup("<span font_desc=\"15.0\">.csv</span>")
hbox$packStart(label,FALSE,FALSE,0)

############################ Export OE gene list ####################################
hbox = gtkHBoxNew(FALSE,20)
vbox$packStart(hbox, FALSE, FALSE, 0)

label = gtkLabelNewWithMnemonic("Export file name for the OE gene list?")
label$setMarkup("<span font_desc=\"15.0\">Export file name for the OE gene list?  </span>")
hbox$packStart(label,FALSE,FALSE,0)
exListFileName = gtkEntryNew()
exListFileName$setText("OEgenes")
exListFileName$setSizeRequest(200,23)
hbox$packStart(exListFileName,FALSE,FALSE,0)
label$setMnemonicWidget(exListFileName)
label = gtkLabel(".csv")
label$setMarkup("<span font_desc=\"15.0\">.csv</span>")
hbox$packStart(label,FALSE,FALSE,0)

############################ Export OE pval  ####################################
hbox = gtkHBoxNew(FALSE,20)
vbox$packStart(hbox, FALSE, FALSE, 0)

label = gtkLabelNewWithMnemonic("Export file name for the p values? ")
label$setMarkup("<span font_desc=\"15.0\">Export file name for the p values?  </span>")
hbox$packStart(label,FALSE,FALSE,0)
exPVFileName = gtkEntryNew()
exPVFileName$setText("pval")
exPVFileName$setSizeRequest(200,23)
hbox$packStart(exPVFileName,FALSE,FALSE,0)
label$setMnemonicWidget(exPVFileName)
label = gtkLabel(".csv")
label$setMarkup("<span font_desc=\"15.0\">.csv</span>")
hbox$packStart(label,FALSE,FALSE,0)

############################## Plot or not ####################

hbox = gtkHBoxNew(FALSE,8)
vbox$packStart(hbox, FALSE, FALSE, 0)

label = gtkLabelNewWithMnemonic("Plot OE genes?")
label$setMarkup("<span font_desc=\"15.0\">Plot OE genes? </span>")
hbox$packStart(label,F,F,0)
#vbox <- gtkVBox(FALSE, 0)
Plot_buttons <- NULL
button <- gtkRadioButton(Plot_buttons, "yes")
hbox$packStart(button,F,F,0)
Plot_buttons <- c(Plot_buttons, button)
button <- gtkRadioButton(Plot_buttons, "no")
hbox$add(button)
Plot_buttons <- c(Plot_buttons, button)

############# Plot num gene ####################
#hbox = gtkHBoxNew(FALSE,20)
#vbox$packStart(hbox, FALSE, FALSE, 0)

label = gtkLabelNewWithMnemonic("Number of genes to plot (if not specified, all OE genes will be plotted)")
label$setMarkup("<span font_desc=\"15.0\">Number of genes to plot (if not specified, 
all OE genes will be plotted) </span>")
hbox$packStart(label,FALSE,FALSE,0)
PlotNum = gtkEntryNew()
PlotNum$setText("")
PlotNum$setSizeRequest(50,23)
label$setMnemonicWidget(PlotNum)
								hbox$packStart(PlotNum,FALSE,FALSE,0)

############### Plot file name ##################
hbox = gtkHBoxNew(FALSE,20)
vbox$packStart(hbox, FALSE, FALSE, 0)

label = gtkLabelNewWithMnemonic("Export file name for the plots? ")
label$setMarkup("<span font_desc=\"15.0\">Export file name for the plots?  </span>")
hbox$packStart(label,FALSE,FALSE,0)
exPlotFileName = gtkEntryNew()
exPlotFileName$setText("Plots")
exPlotFileName$setSizeRequest(200,23)
hbox$packStart(exPlotFileName,FALSE,FALSE,0)
label$setMnemonicWidget(exPlotFileName)
label = gtkLabel(".pdf")
label$setMarkup("<span font_desc=\"15.0\">.pdf</span>")
hbox$packStart(label,FALSE,FALSE,0)







performStatistics <- function(button, user.data) {
	# Get the information about data and the file
	
	# grouping
	Group.file=GroupVector$getText()
	GroupB=ifelse(Group.file=="",FALSE,TRUE)
	GroupV=NULL
	cat(paste0("\nGruouping info ? ", GroupB ,"\t"))
	cat(Group.file)
	if(GroupB==TRUE){
		Group.Sep=strsplit(Group.file,split="\\.")[[1]]
		if(Group.Sep[length(Group.Sep)]%in%c("xls"))
		GroupVIn=read.xls(Group.file,stringsAsFactors=F,header=F)
		if(Group.Sep[length(Group.Sep)]=="csv")
		GroupVIn=read.csv(Group.file,stringsAsFactors=F,header=F)
		if(Group.Sep[length(Group.Sep)]%in%c("txt","tab"))
		GroupVIn=read.table(Group.file,stringsAsFactors=F,header=F, sep="\t")	
		GroupV=GroupVIn[[1]]
		}

	Num=as.numeric(GroupNum$getText())

	# normalization
	cat("\nNeed Normalization ? ")
	cat(gtkToggleButtonGetActive(Norm_buttons[[1]]))
	NormTF=gtkToggleButtonGetActive(Norm_buttons[[1]])

  cat("\nRemove or imput? ")
	RMTF=gtkToggleButtonGetActive(RM_buttons[[1]])
  if(RMTF) cat("Remove")
	else cat("Imput")

	the.file <- filename$getText()
	FDR<-as.numeric(TgtFDR$getText())
	cat(paste0("\np-value cutoff ", FDR))
  LODNum <- as.numeric(LOD$getText()) 	
	cat(paste0("\nlower limit of detection ", LODNum))
	NumPermu <- as.numeric(PermIn$getText())
	cat(paste0("\nnum permutation ", NumPermu))
	Dir <- Outdir$getText()
	

	tmp=strsplit(the.file,split="/")[[1]]
	InDir=paste0(tmp[-length(tmp)],collapse="/")
	InDir=paste0(InDir,"/")
	if(Dir=="")Dir=InDir
	cat(paste0("\nOutput directory:",Dir,"\n"))	
	# output
	exExpF=paste0(Dir,exNormFileName$getText(),".csv")
	exOEF=paste0(Dir,exListFileName$getText(),".csv")
	exPVF=paste0(Dir,exPVFileName$getText(),".csv")


	# plot
  cat("\nOutput plot ? ")
  cat(gtkToggleButtonGetActive(Plot_buttons[[1]]))
  PlotTF=gtkToggleButtonGetActive(Plot_buttons[[1]])	
	PlotF=paste0(Dir,exPlotFileName$getText(),".pdf")
	PlotN=as.numeric(PlotNum$getText())
	#print(str(PlotN))
	if(is.na(PlotN))PlotN <- NULL
	###### read in #############
	cat("\n\nData read in:")
	cat(the.file)
 	Sep=strsplit(the.file,split="\\.")[[1]]
  if(Sep[length(Sep)]%in%c("xls"))a1=read.xls(the.file,stringsAsFactors=F,header=TRUE, row.names=1)
  if(Sep[length(Sep)]=="csv")a1=read.csv(the.file,stringsAsFactors=F,header=TRUE, row.names=1)
  if(Sep[length(Sep)]%in%c("txt","tab"))a1=read.table(the.file,stringsAsFactors=F,header=TRUE, row.names=1)
	Data=data.matrix(a1)
	cat("\n\nInput data \n")
	print(str(Data))
	
	DataUse0=Data
	if(NormTF){
		library(EBSeq)
			Sizes <- MedianNorm(DataUse0)
					if(is.na(Sizes)){
					Sizes <- MedianNorm(DataUse0, alternative=T)
					print("alternative normalization is applied - all genes have at least one zeros")
			}
		DataUse0=GetNormalizedMat(Data,Sizes)
	}
	DataUse=DataUse0[which(rowMeans(DataUse0)>LODNum),]
	cat("\n\nGenes passed LOD threshold: \n")
	print(str(DataUse))
	cat(paste0("\n\n# genes to test: ", nrow(DataUse)))
	if(PlotTF)pdf(PlotF, height=15,width=15)
	Res=FindOEfun(Data=DataUse, Group = GroupV , Poly = 2, Nchunk = Num, Sigcut = FDR, MeanLOD=LODNum,
								     Plot = PlotTF, NumPlot = PlotN, numNullgenes=NumPermu, 
										 numPermu=ceiling(NumPermu/(nrow(DataUse))*5),
										   Seed=1, mfrow=c(5,4))
  if(PlotTF)dev.off()
# output
	Sig=matrix(Res$Sig,ncol=1)
	rownames(Sig)=names(Res$Sig)
	colnames(Sig)="p-value"

	Allp=matrix(Res$Allpsort,ncol=1)
	rownames(Allp)=names(Res$Allpsort)
	colnames(Allp)="p-value"
	write.csv(Sig,file=exOEF)
	cat(paste0("\n\nNum OE genes: ", length(Res$Sig)))
	write.csv(Allp,file=exPVF)
	if(RMTF)write.csv(Res$CleanedData, file=exExpF)
	else write.csv(Res$AdjustedData, file=exExpF)
	cat("\n Done \n")
			
}


# Add button
the.buttons = gtkHButtonBoxNew()
the.buttons$setBorderWidth(5)
vbox$add(the.buttons)
the.buttons$setLayout("spread")
the.buttons$setSpacing(60)
buttonOK = gtkButtonNewFromStock("gtk-ok")
gSignalConnect(buttonOK, "clicked", performStatistics)
the.buttons$packStart(buttonOK,fill=F)
buttonCancel = gtkButtonNewFromStock("gtk-close")
gSignalConnect(buttonCancel, "clicked", window$destroy)
the.buttons$packStart(buttonCancel,fill=F)

}
