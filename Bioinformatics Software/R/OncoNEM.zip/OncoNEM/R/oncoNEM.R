########################## Wrapper for C++ functions. ##########################

#' OncoNEM class
#' 
#' The reference class (see \link[methods]{ReferenceClasses}) 'oncoNEM' contains methods for oncoNEM inference.
#' 
#' @name oncoNEM
#' @export oncoNEM
#' @field Data Matrix of observed genotypes. Needed for initialization.
#' @field FPR Vector of false positive rate(s). Needed for initialization.
#' @field FNR Vector of false negative rate(s). Needed for initialization.
#' @field TF Field for C++ tree finder object.
#' @field best List containig best tree scored so far where entry \code{tree} 
#' contains highest scoring tree in 0-based vector format and \code{llh} is its
#' log-likelihood.
#' @method initialize
#' @method search
#' @method addTree
#' @return An object of class oncoNEM.
#' @seealso \code{\link{getNBestTrees}}, See \code{\link{ssave}} for a safe way 
#' to save objects of this type.
#' @examples
#' ## simulate example data set
#' dat <- simulateData()
#' ## initialize oncoNEM object
#' oNEM <- oncoNEM(dat$D,dat$FPR,dat$FNR)
#' ## add additional start tree for initial search (is usually skipped)
#' oNEM$addTree(0:(ncol(dat$D)-1))
#' ## run initial search until best tree has not changed for 10 steps
#' oNEM$search(delta=10)
oncoNEM <- setRefClass("oncoNEM",
                    fields = c(Data="matrix",
                               FPR="vector",
                               FNR="vector",
                               TF="ANY",
                               best="list"),
                    methods = list(
                      initialize = function(Data,FPR,FNR) {
"Initializes fields of a new oncoNEM object and adds a tree with star topology
as start tree. This function gets invoked automatically when an object is 
generated from this class."

                        data <- Data               
                        fpr <- FPR
                        fnr <- FNR
                        
                        ## test input
                        if (any(fpr<=0)|any(fnr<=0)|any(fpr>=1)|any(fnr>=1)) {
                          stop("FPR and FNR must be geater than 0 and smaller than 1.")
                        }
                        
                        n = ncol(data) ## number of non-root nodes
                        
                        numOutcomes <- max(length(fpr),length(fnr)) * 2 + 1
                        
                        ## encode NAs as 2 in data for C++ compatibility
                        if (any(is.na(data))) {
                          if (any(data==2,na.rm=TRUE)) {
                            stop("Unknown encoding for data observed. data contains both 'NA' and '2'.")
                          } else {
                            data[is.na(data)] <- 2
                          }
                        }
                        
                        ## assign data field
                        Data <<- data
                        
                        if ( numOutcomes > 3) {
                          if (length(fnr)==1) {
                            fnr <- rep(fnr,n)
                          } else if (length(fnr)!=n) {
                            stop("Length of vector fnr does not match. Should be ncol(Data) =",
                                        n,"or 1.")
                          } 
                          if (length(fpr)==1) {
                            fpr <- rep(fpr,n)
                          } else if (length(fpr)!=n) {
                            stop("Length of vector FPR does not match. Should be ncol(Data) =",
                                        n,"or 1.")
                          }    
                          
                          ## change encoding of Data
                          indx <- data==2
                          data <- t(apply(data,1,function(x) x+(0:(length(x)-1)*2)))
                          data[indx] <- (numOutcomes-1)
                          
                        }
                        
                        ## write error rates into scoring matrices
                        predNeg <- c(as.vector(t(cbind(1-fpr,  ## true negative
                                                       fpr))), ## false positive 
                                     1)                        ## missing value
                        
                        predPos <- c(as.vector(t(cbind(fnr,      ## false negative
                                                       1-fnr))), ## true positive
                                     1)                          ## missing value
                        
                        
                        
                        ## construct new TreeFinder object
                        tf <- new(TreeFinder, predPos, predNeg, data)
                        tf$addTree(rep(0,n))
                        
                        ## assign other fields
                        FPR <<- fpr
                        FNR <<- fnr
                        TF <<- tf
                        
                        best$tree <<- .self$TF$getTreeList(1)[1,]
                        best$llh <<- .self$TF$getScoreList(1)
                        
                        .self$search # force definition for tab completion
                        .self$addTree # force definition for tab completion
                      },
                      
                      copy = function() {
                        warning("Field TF cannot be copied.")
                        oncoNEMcopy <- oncoNEM$new(Data,FPR,FNR)
                        oncoNEMcopy$TF <- NULL
                        return(oncoNEMcopy)
                      },
                      
                      save = function(file) {
                        warning("Field TF is C++ object an cannot be saved.")
                        oncoNEMcopy <- oncoNEM$new(Data,FPR,FNR)
                        oncoNEMcopy$TF <- NULL
                        base::save(oncoNEMcopy, file=file)
                      },
                      
                      search = function(nSteps=NULL,delta=NULL,verbose=FALSE) {
"Runs the heuristic serach algorithm for \\code{nSteps} or until highest scoring
tree has not changed for delta steps. Only one of the two arguments can be used.
If search has been run previously, search continues based on previous results."
                        
                        if (is.null(delta) && is.null(nSteps)) {
                          stop("Either 'delta' or 'nSteps' must be provided.")
                        } else if (is.null(delta)) {
                          ans <- .self$TF$find(nSteps,swap=TRUE)
                        } else if (is.null(nSteps)) {
                          ans <- .self$TF$find2(delta,swap=TRUE)
                        } else {
                          stop("Only one of the parameters 'delta' and 'nSteps' can be used. The 
                                other one should be NULL.")
                        }

                        if (verbose) {
                          message(ans)
                        }
                        best$tree <<- .self$TF$getTreeList(1)[1,]
                        best$llh <<- .self$TF$getScoreList(1)
                      },
                      
                      addTree = function(tree) {                        
"Adds tree to TF object and updates field \\code{best} if applicable."
                        
                        .self$TF$addTree(tree)
                        
                        ## update best tree and its llh
                        if (.self$TF$getScoreList(1)>best$llh) {
                          best$tree <<- .self$TF$getTreeList(1)[1,]
                          best$llh <<- .self$TF$getScoreList(1)
                        }
                      }
                    )
)
oncoNEM$lock("Data")
oncoNEM$lock("FPR")
oncoNEM$lock("FNR")

#' Function to safely save oncoNEM objects.
#' 
#' Makes sure that oncoNEM objects that are being saved do not contain C++ object
#' as loading such objects into R can cause segmentation fualt.
#' 
#' @export
#' @inheritParams base::save
#' @param objs Vector of character strings of objects to be saved.
#' @section Warning:
#' oncoNEM$TF is not available anymore after saving and reloading. If oncoNEM is
#' saved using standard \code{\link[base]{save}}, accessing oncoNEM$TF of the 
#' reloaded object causes a segmentation fault.
ssave <- function(objs,file = stop("'file' must be specified"),
                  ascii = FALSE, version = NULL, envir = parent.frame(),
                  compress = !ascii, eval.promises = TRUE, precheck = TRUE) {
  i=0
  for (oString in objs) {
    if(is(get(oString), 'oncoNEM')) {
      i=i+1
      assign(paste0('tmp',i), get(oString)) ## save to tmp object
      suppressWarnings(assign(oString,  get(oString)$copy(),envir = parent.frame())) ## turn obj to save into safe copy of current object
    }
  }
  
  save(list=objs,file = file, ascii = ascii, version = version, envir = envir,
       compress = compress, eval.promises = eval.promises,
       precheck = precheck)
  
  i=0
  for (oString in objs) {
    if (is(get(oString),'oncoNEM')) {
     i=i+1
     assign(oString, get(paste0('tmp',i)), envir = parent.frame())     
    }
  }
}


#' Extract best trees
#' 
#' Returns N best trees of oncoNEM object in vector format as well as their 
#' respecitve log-likelihoods.
#' 
#' @export
#' @param oNEM Object of oncoNEM class.
#' @param N number of trees to return.
#' @return A list containing the trees and llhs.
#' @note If N is greater than the number of trees scored so far, function returns
#' all trees scored so far.
#' @examples
#' ## simulate example data set
#' dat <- simulateData()
#' ## initialize oncoNEM object
#' oNEM <- oncoNEM(dat$D,dat$FPR,dat$FNR)
#' ## run initial search until best tree has not changed for 10 steps
#' oNEM$search(delta=10)
#' ## print 5 best trees
#' getNBestTrees(oNEM,5)
getNBestTrees <- function(oNEM,N) {  
  llhs <- oNEM$TF$getScoreList(N)
  trees <- as.data.frame(t(oNEM$TF$getTreeList(N)))
  colnames(trees) <- paste0('Tree',1:N)
  return(list(tree=trees,llh=llhs))
}


#' Calculate LLH of a tree
#'
#' \code{scoreTree} calculates the marginal log-likelihood of a tree given the
#' observed genotypes.
#' 
#' @export
#' @param tree An igraph object or a tree in vector format where the i-th 
#' element corresponds to the parent of node i and the root has index 0.
#' @param clones List in which the i-th element corresponds to node i in the 
#' tree and contains the indices of all cells belonging to that clone. Should be
#' set to NULL if tree is a cell lineage tree.
#' @param indx.inferred logical. Have node indices of the tree been inferred 
#' (default=TRUE) or do they match \code{colnames(Data)}?
#' @param Data Matrix of observed genotypes.
#' @param FPR Vector of false positive rate(s).
#' @param FNR Vector of false negative rate(s).
#' @examples 
#' ## simulate example data set
#' dat <- simulateData()
#' ## score a single tree
#' scoreTree(tree=dat$g,clones=dat$clones,Data=dat$D,FPR=dat$FPR,FNR=dat$FNR)
scoreTree <- function(tree,clones,Data,FPR,FNR,indx.inferred=TRUE) {
  
  cond.prob <- array(1,dim=c(2,3,ncol(Data)))
  cond.prob[1,1,] <- 1-FPR
  cond.prob[1,2,] <- FPR
  cond.prob[2,1,] <- FNR
  cond.prob[2,2,] <- 1-FNR
  
  ## get Prediction matrix
  if (igraph::is.igraph(tree)) {
    el <- igraph::get.edgelist(tree)
  } else if (is.vector(tree)) {
    if (!any(tree==0)) {
      warning("Tree is not 0-based or in wrong format. Converting to 0-based 
              indices...")
      tree <- tree-1
    }
    el <- cbind(tree+1,2:(length(tree)+1))
  } else {
    stop("Unknown tree format. See ?scoreTree for help.")
  }
  
  Pred <- transitiveClosure(el=el, returnAdjMat = TRUE)
  
  ## reformat prediction matrix
  if (is.null(clones)) {
    if (nrow(el)<ncol(Data)) {
      stop("Number of clones does not match number of data columns.")
    } else {
      if (!indx.inferred) {
        colnames(Pred) <- 1:ncol(Pred)
        Pred <- Pred[-1,colnames(Data)]
      } else {
        Pred <- Pred[-1,-1]
        Pred <- Pred[,1:ncol(Data)] ## if Pred has more columns than Data, el 
        ## contains hidden nodes which have highest index and need to be removed
        ## because they are not scored
      }
    }
  } else{
    if (!indx.inferred) {
      ## for every cell in Data find corresponding clone
      indx <- sapply(as.numeric(colnames(Data)),
                     function(x) which(sapply(clones,function(c) x%in%c)))
      Pred <- Pred[-1,indx] # (Pred=clones x cells)
      colnames(Pred) <- colnames(Data)
    } else {
      ## for each cell get corresponding clone (ordered by cell index)
      indx <- rep(1:length(clones),sapply(clones,length))[order(unlist(clones))] 
      Pred <- Pred[,indx]
      colnames(Pred) <- sort(unlist(clones))
      Pred <- Pred[-1,]
      Pred <- Pred[,1:ncol(Data)] ## if Pred has more columns than Data, el 
      ## contains hidden nodes which have highest index and need to be removed
      ## because they are not scored
    }
  }
  ## calculate marginal log likelihood
  -nrow(Data)*log(nrow(Pred)) + 
    sum(log(apply(Data,1,function(x) sum(apply(Pred,1,function(pred,obs,cond.prob)
      prod(cond.prob[cbind(pred+1,obs+1,1:length(obs))]),obs=x,cond.prob)))))
}

#' Posteriors of oncoNEM
#' 
#' \code{oncoNEMposteriors} calculates the posterior probability of the 
#' occurrence parameter theta as well as the posterior probability of the 
#' presence of a mutation for every cell and locus, given a tree model and the
#' observed genotypes.
#' 
#' @export
#' @inheritParams scoreTree
#' @return list containing \code{p_theta} (the posterior of the occurrence 
#' parameter) and \code{p_mut} (the posterior probability of having a mutation
#' in a certain cell at a given locus which is calculated as the sum of p_theta 
#' over all ancestors for cell and that locus).
#' @note Cell indices and names of Data columns (if numbers) have to match.
#' @examples
#' ## simulate example data set
#' dat <- simulateData()
#' post <- oncoNEMposteriors(tree = dat$g,
#'                          clones = dat$clones,
#'                          Data = dat$D,
#'                          FPR = dat$FPR,
#'                          FNR = dat$FNR)
#' ## compare estimated edge lengths to true ones
#' cbind(estimated=colSums(post$p_theta)[-1],
#'       true=table(dat$theta))
oncoNEMposteriors <- function(tree,clones=NULL,Data,FPR,FNR) {
  
  cond.prob <- array(1,dim=c(2,3,ncol(Data)))
  cond.prob[1,1,] <- 1-FPR
  cond.prob[1,2,] <- FPR
  cond.prob[2,1,] <- FNR
  cond.prob[2,2,] <- 1-FNR
  
  ## get Prediction matrix
  if (igraph::is.igraph(tree)) {
    el <- igraph::get.edgelist(tree)
  } else if (is.vector(tree)) {
    if (!any(tree==0)) {
      warning("Tree is not 0-based or in wrong format. Converting to 0-based 
              indices...")
      tree <- tree-1
    }
    el <- cbind(tree+1,2:(length(tree)+1))
  } else {
    stop("Unknown tree format. See ?postProbTree for help.")
  }
  
  Pred <- transitiveClosure(el=el, returnAdjMat = TRUE)
  
  if (is.null(clones)) {
    Pred <- Pred[,-1]
  } else {
    clones_byCell <- rep(1:length(clones),sapply(clones,length))[order(unlist(clones))]
    Pred <- Pred[,clones_byCell] 
  }
  
  if (suppressWarnings(all(!is.na(as.numeric(colnames(Data)))))&!is.null(colnames(Data))) {
    Data <- Data[,order(as.numeric(colnames(Data)))]
  }
  
  ## posterior probability of occurrence parameter theta
  p_theta <- matrix(0,nrow=nrow(Data),ncol=nrow(Pred)-1)
  for (i in 1:nrow(Data)) {
    p_theta[i,] <- apply(Pred[-1,,drop=FALSE],1,
                         function(pred,obs,cond.prob) prod(cond.prob[cbind(pred+1,obs+1,1:length(obs))]),
                         obs=Data[i,],cond.prob)
  }
  
  ## normalize by 1/Z
  p_theta <- p_theta/rowSums(p_theta)
  
  ## add row for normal clone
  p_theta <- cbind(0,p_theta)
  
  ## calculate posterior probability of having a mutation at certain locus in
  ## a given cell as sum over p_theta probabilities along branches.
  p_mut <- apply(Pred,2,function(x) rowSums(p_theta[,x==1,drop=FALSE]))
  
  return(list(p_theta=p_theta,p_mut=p_mut))
}

# Function to finds branch points of trees
#
# @param tree Tree in vector format.
# @param indx.hidden Indices of hidden nodes. NULL (default) if tree contrains no hidden nodes.
# @note Used by expandTree
findForks <- function(tree,indx.hidden=NULL) {
  ## find all nodes which have at least two children
  forks <- unique(tree[duplicated(tree)])
  
  ## exclude hidden nodes
  if (length(indx.hidden)>0) {
    forks <- forks[!forks%in%indx.hidden]
  }
  
  return(sort(forks))
}

# Expands a tree
# 
# Returns a matrix that contains all possible expansions of a given tree with a single added hidden node.
# More precisely, it returns a matrix in which every column is an expanded tree, i.e. all trees that can be obtained by
# inserting an unobserved node into a branch point specified by forks.
# 
# @param tree Tree in vector format.
# @param forks Branch points of tree. Can be obtained by findForks(tree).
expandTree <- function(tree,forks) {
  indx.new <- length(tree)+1
  ## each column is a tree where indx.new is the new parent of all children of fork[i]
  vapply(forks,function(fork) {
    expTree <- tree
    expTree[tree==fork] <- indx.new
    expTree <- c(expTree,fork)
    return(expTree)
  },FUN.VALUE=c(tree,0))
}

#' Adds unobserved nodes to tree
#' 
#' \code{expandOncoNEM} tests if adding unobserved nodes to the tree improves 
#' the marginal likelihood and returns the tree with the optimal number of
#' unobserved nodes (including 0).
#' 
#' @export
#' @param oNEM oncoNEM object containing the results of the initial search 
#' performed by \code{oNEM$search()}.
#' @param epsilon Numeric. Maximum Bayes factor for which smaller model is preferred.
#' @param delta Integer. Search stops when best scoring tree has not changed for 
#' at least \code{delta} steps.
#' @param nSteps Integer. Maximum number of search steps to perform. If used, delta
#' must be set to \code{NULL}.
#' @param checkMax Integer. Maximum number of highest scoring trees which are tested for 
#' position of unobserved clones. (default = NULL)
#' @param app Logical. Should trees be tested for position of unobserved clones
#' using apply (TRUE) or for loop (FALSE, default).
#' @param verbose Logical. Should function print intermediate scores during processing (default is FALSE).
#' @return Tree in vector format, where i-th entry denotes parent of node i+1. 
#' Node indices correspond to columns of Data matrix. If \code{length(returned 
#' tree) > ncol(Data)}, unobserved nodes have been added. 
#' @examples
#' ## simulate example data set
#' set.seed(1)
#' dat <- simulateData(N.cells=20,N.clones=5,N.unobs=1)
#' ## initialize oncoNEM object
#' oNEM <- oncoNEM(dat$D,dat$FPR,dat$FNR)
#' ## run initial search until best tree has not changed for 10 steps
#' oNEM$search(delta = 10)
#' length(oNEM$best$tree)
#' ## search for unobserved subpopulations
#' oNEM.expanded <- expandOncoNEM(oNEM, epsilon = 10,delta = 10)
#' length(oNEM.expanded$best$tree)
expandOncoNEM <- function(oNEM,epsilon,delta=NULL,nSteps=NULL,checkMax=NULL,
                          app=FALSE,verbose=FALSE) {
  
  bestTree <- oNEM$best$tree
  maxScore <- oNEM$best$llh
  Data <- oNEM$Data
  FPR <- oNEM$FPR
  FNR <- oNEM$FNR
  oNEM.current <- oNEM
  
  expand <- TRUE
  indx.hidden <- vector()
  
  while (expand) {
    if (verbose) {
      message(maxScore)
    }
    ## identify start trees
    forks <- findForks(tree = oNEM.current$best$tree,indx.hidden = indx.hidden)
    expandedTrees <- expandTree(oNEM.current$best$tree,forks)
    
    ## test if expansion increases score
    Data <- cbind(Data,rep(2,nrow(Data)))
    if (length(FPR)>1) {
      FPR <- c(FPR,1) ## add scoring value for NA case
    }
    if (length(FNR)>1) {
      FNR <- c(FNR,1)
    }
    indx.hidden <- c(indx.hidden,ncol(Data)) ## index/indices of hidden nodes
    
    oNEM.expanded <- oncoNEM$new(Data=Data,FPR = FPR,FNR = FNR)
    
    ## add expanded Trees as start trees
    if (ncol(expandedTrees)>0) { ## previous tree has at least one fork
      for (i in 1:ncol(expandedTrees)) {
        oNEM.expanded$addTree(tree=expandedTrees[,i])
      }    
    }
    if (is.null(delta) && is.null(nSteps)) {
      stop("Either 'delta' or 'nSteps' must be provided.")
    } else if (is.null(delta)) {
      oNEM.expanded$search(nSteps=nSteps)
    } else if (is.null(nSteps)) {
      oNEM.expanded$search(delta=delta)
    } else {
      stop("Only one of the parameters 'delta' and 'nSteps' can be used. The other one should be NULL.")
    }
    
    ## find expanded trees that pass Bayes factor threshold
    indx.pass <- which((oNEM.expanded$TF$getScoreList(oNEM.expanded$TF$getNConsideredTrees()) -maxScore)>log(epsilon))
    
    if (!is.null(checkMax)&& length(indx.pass)>checkMax) {
      indx.pass <- indx.pass[1:checkMax]
    }
    
    ## find bestTree in which all hidden nodes were inserted at a branch point
    found <- FALSE
    
    if (app) {
      
      trees <- oNEM.expanded$TF$getTreeList(length(indx.pass))
      idx <- apply(trees,1,function(tree) all(sapply(indx.hidden,function(x) sum(tree==x)>=2)))
      if (any(idx)) {
        i <- which.max(idx)
        found <- TRUE
        if (verbose) {
          message(paste("Pass",i))
          message(paste("Log (Bayes factor) =",oNEM.expanded$TF$getScoreList(i)[i] - maxScore))
        }
        oNEM.expanded$best$llh <- maxScore <- oNEM.expanded$TF$getScoreList(i)[i]
        oNEM.expanded$best$tree <- bestTree <- oNEM.expanded$TF$getTreeList(i)[i,]
        oNEM.current <- oNEM.expanded
      } 
      
    } else {
      i <- 1
      while(i<=length(indx.pass)&&!found) {
        if (all(sapply(indx.hidden,function(x) sum(oNEM.expanded$TF$getTreeList(i)[i,]==x)>=2))) {
          found <- TRUE
          message(paste("Pass",i))
          message(paste("Log (Bayes factor) =",oNEM.expanded$TF$getScoreList(i)[i] - maxScore))
          oNEM.expanded$best$llh <- maxScore <- oNEM.expanded$TF$getScoreList(i)[i]
          oNEM.expanded$best$tree <- bestTree <- oNEM.expanded$TF$getTreeList(i)[i,]
          oNEM.current <- oNEM.expanded
        } else {
          i=i+1
        }
      }
    }
    if (!found) {
      expand=FALSE
      indx.hidden <- indx.hidden[-length(indx.hidden)]
    }
  }
  return(oNEM.current)
}

#' Clusters a cell lineage tree into a clonal lineage tree.
#'
#' \code{clusterOncoNEM} clusters nodes of a cell lineage tree along branches 
#' into clones if this increases the likelihood of the tree or the likelihood 
#' does not decrease significantly, which is defined by the Bayes factor 
#' threshold \code{epsilon}.
#' 
#' @export
#' @inheritParams scoreTree
#' @param oNEM An oncoNEM object. The highest scoring tree of this object will be used for clustering.
#' @param epsilon Numeric. Maximum Bayes factor for which smaller model is preferred. See corresponding paper for details.
#' @param verbose Logical. Should function print intermediate scores during processing (default is FALSE).
#' @note Before running this function, please initialize an oncoNEM object, run the initial search algorithm oncoNEM$search() and 
#' consider testing for unobserved nodes using expandOncoNEM.
#' @seealso \code{\link{oncoNEM}}, \code{\link{expandOncoNEM}}
#' @return Returns a list containing \describe{
#' \item{\code{g}}{the clonal lineage tree as igraph}
#' \item{\code{clones}}{a list of clones where list entry i corresponds to node 
#' i of the tree}
#' \item{\code{llh}}{the marginal log-likelihood of the tree}.}
#' @examples 
#' ## simulate example data set
#' dat <- simulateData(N.cells=20,N.clones=5)
#' ## initialize oncoNEM object
#' oNEM <- oncoNEM(dat$D,dat$FPR,dat$FNR)
#' ## run initial search until best tree has not changed for 10 steps
#' oNEM$search(delta = 10)
#' length(oNEM$best$tree)
#' ## cluster cells into subpopulations along edges of tree
#' oncoTree <- clusterOncoNEM(oNEM, epsilon = 10)
#' igraph::vcount(oncoTree$g)
#' oncoTree$clones
clusterOncoNEM  <- function(oNEM,epsilon,verbose=FALSE) {  
  
  Data <- oNEM$Data
  ## 
  cloneAllocation <- (1:ncol(Data)) ## start with cell lineage tree where
                                    ## every cell is in separate cluster  
  Data <- Data[,apply(Data,2,function(x) !all(x==2))]
  
  ## start tree
  tree <- oNEM$best$tree
  scoreMax <- scoreCurrent <- oNEM$best$llh
    
  ## check if tree contains unobserved nodes
  indx.hidden <- NULL
  if (length(tree) > ncol(Data)) { ## tree contains hidden nodes
    indx.hidden <- ((ncol(Data)+1):length(tree))
  } else if (length(tree) < ncol(Data)) {
    stop("Tree size and data set size not compatible. Has tree already been clustered?")
  }
  
  ## start clustering
  collapse <- TRUE
  ## initialize new scoring object (neccesary if oNEM object has been saved and reloaded)
  oNEMCluster <- oncoNEM$new(Data=oNEM$Data,FPR=oNEM$FPR,FNR=oNEM$FNR)
  ## collapse until we reach bayes threshold or tree has only two nodes left
  while (collapse&&length(tree)>1) {
    edgeScores <- rep(0,length(tree))
    for (i in 1:length(tree)) {
      ## cluster edge and score clustered solution
      treeCurr <- tree[-i]
      treeCurr[treeCurr==i] <- tree[i]
      treeCurr[treeCurr>i] <- treeCurr[treeCurr>i]-1
      cloneAllocCurr <- cloneAllocation
      cloneAllocCurr[cloneAllocCurr==i] <- tree[i]
      cloneAllocCurr[cloneAllocCurr>i] <- cloneAllocCurr[cloneAllocCurr>i]-1
      
      edgeScores[i] <- oNEMCluster$TF$scoreCluster(treeCurr,cloneAllocCurr)
    }
    
    i <- which.max(edgeScores)
    if (scoreCurrent-max(edgeScores)<=log(epsilon)) {
      ## update best solution found so far
      newTree <- tree[-i]
      newTree[newTree==i] <- tree[i]
      newTree[newTree>i] <- newTree[newTree>i]-1
      cloneAllocNew <- cloneAllocation
      cloneAllocNew[cloneAllocNew==i] <- tree[i]
      cloneAllocNew[cloneAllocNew>i] <- cloneAllocNew[cloneAllocNew>i]-1
      
      tree <- newTree
      cloneAllocation <- cloneAllocNew
      scoreCurrent <- max(edgeScores)
      if (verbose) {
        message(scoreCurrent)
      }
      ## update highest score found so far if applicable
      if (max(edgeScores)>scoreMax) {
        scoreMax <- max(edgeScores)
      }
    } else {
      ## stop clustering
      collapse <- FALSE
    }
    
  }
  
  el <- cbind(tree+1,2:(length(tree)+1))  
  g=igraph::graph.edgelist(el)
  
  clones <- lapply(1:igraph::vcount(g), 
                   function(i) which(cloneAllocation+1==i))
    
  if (!is.null(indx.hidden)) {
    ## remove hidden clones if they cluster with observed nodes
    clones <- lapply(clones,function(x) {
      if (length(x)>sum(x%in%indx.hidden)) { ## cluster with observed nodes
        x[!x%in%indx.hidden]
      } else { ## separate cluster
        integer()
      }
    })
  }
  
  return(list(g=g,clones=clones,llh=scoreCurrent))
  
}



#' Calculates distance between two trees.
#' 
#' First, this function calculates the pairwise distances between all cells (including the normal root) in 
#' both trees. Then, the absolute differences between the pairwise distances are
#' calculated and summed up to obtain the distance between the two trees. 
#' 
#' @export
#' @param tree1 Either a cell lineage tree in vector format (0-based), or a list 
#' containing a clonal lineage tree in from of an igraph \code{g} and a list 
#' defining the clones where the i-th entry corresponds to node i of \code{g}.
#' @param tree2 Tree of same format as \code{tree1}. Indices of cells need to 
#' match between the two trees.
#' @param root1 Clone index of root in tree1. Only used if tree1 is an undirected igraph object.
#' @param root2 Clone index of root in tree2. Only used if tree2 is an undirected igraph object.
#' @return The distance between the two given trees.
#' @examples
#' ## simulate example data set
#' dat <- simulateData(N.cells=20,N.clones=20)
#' ## initialize oncoNEM object
#' oNEM <- oncoNEM(dat$D,dat$FPR,dat$FNR)
#' ## run initial search until best tree has not changed for 100 steps
#' oNEM$search(delta = 100)
#' ## Compare inferred tree to ground truth
#' treeDistance(tree1=dat,tree2=oNEM$best$tree)
treeDistance <- function(tree1,tree2,root1=NULL,root2=NULL) {
  
  idx0addedTo1 <- FALSE
  idx0addedTo2 <- FALSE
  
  ## test and convert input
  if (!is.list(tree1)&&is.vector(tree1)) {
    ## if tree in vector format (cell tree), convert to igraph
    t1 <- vector('list')
    t1$g <- igraph::graph.edgelist(cbind(tree1+1,2:(length(tree1)+1)))
    ## every cell is in separate clone + add extra cell with idx 0 to root
    t1$clones <- as.list(0:length(tree1))
    idx0addedTo1 <- TRUE
    tree1 <- t1
  } else if (!is.list(tree1) || !igraph::is.igraph(tree1$g) ) {
    stop("tree1 has unknown input format. See ?treeDistance for help.")
  }
  if (!is.list(tree2)&&is.vector(tree2)) {
    ## if tree in vector format (cell tree), convert to igraph
    t2 <- vector('list')
    t2$g <- igraph::graph.edgelist(cbind(tree2+1,2:(length(tree2)+1)))
    ## every cell is in separate clone + add extra cell with idx 0 to root
    t2$clones <- as.list(2:(length(tree2)+1))
    idx0addedTo2 <- TRUE
    tree2 <- t2
  } else if ( !is.list(tree2) || !igraph::is.igraph(tree2$g) ) {
    stop("tree2 has unknown input format. See ?treeDistance for help.")
  }
  
  ## check if both trees are built on the same set of cells
  if (suppressWarnings(!all( sort(unlist(tree1$clones)) == sort(unlist(tree2$clones)) ))) {
    stop("tree1 and tree2 contain differing cell indices.")
  }
  
  ## 
  if (!idx0addedTo1) {
    ## check if cell indices are 0- or 1-based
    if (any(unlist(tree1$clones)==0)) {
      ## make 1-based
      tree1$clones <- lapply(tree1$clones, function(x) {
        if (length(x)>0) {
          x+1
        }})
    }
    
    if (igraph::is.directed(tree1$g)) {
      root1 <- which(igraph::degree(tree1$g,mode='in')==0)
    } else if (is.null(root1)) {
      stop('Cannot identify root of tree1.')
    } 
    tree1$clones[[root1]] <- c(0,tree1$clones[[root1]])
    idx0addedTo1 <- TRUE
  }
  
  if (!idx0addedTo2) {
    ## check if cell indices are 0- or 1-based
    if (any(unlist(tree2$clones)==0)) {
      ## make 1-based
      tree2$clones <- lapply(tree2$clones, function(x) {
        if (length(x)>0) {
          x+1
        }})
    }
    
    if (igraph::is.directed(tree2$g)) {
      root2 <- which(igraph::degree(tree2$g,mode='in')==0)
    } else if (is.null(root2)) {
      stop('Cannot identify root of tree2.')
    } 
    tree2$clones[[root2]] <- c(0,tree2$clones[[root2]])
    idx0addedTo2 <- TRUE
  }
  
  ## remove edge weights
  if (igraph::is.weighted(tree1$g)){
    tree1$g <- igraph::remove.edge.attribute(tree1$g,"weight")
  }
  if (igraph::is.weighted(tree2$g)) {
    tree2$g <- igraph::remove.edge.attribute(tree2$g,"weight")
  }
  
  ## calculate shortest paths within collapsed trees (clones x clones)
  sp1 <- igraph::shortest.paths(tree1$g)
  sp2 <- igraph::shortest.paths(tree2$g)
  
  ## expand shortest path matrices to cells (cells x cells)
  clone.indx1 <- rep(1:length(tree1$clones),times=sapply(tree1$clones,length))[order(unlist(tree1$clones))]
  full.sp1 <- sp1[clone.indx1,clone.indx1]
  rownames(full.sp1) <- colnames(full.sp1) <- sort(unlist(tree1$clones))
  
  clone.indx2 <- rep(1:length(tree2$clones),times=sapply(tree2$clones,length))[order(unlist(tree2$clones))]
  full.sp2 <- sp2[clone.indx2,clone.indx2]
  rownames(full.sp2) <- colnames(full.sp2) <- sort(unlist(tree2$clones))
  
  ## calculate distances
  m = sum(abs(full.sp1[lower.tri(full.sp1)] - full.sp2[lower.tri(full.sp2)]))
  
  return(m)
}

#' Plotting function for trees
#' 
#' @export
#' @param tree Tree in vector format or an igraph object
#' @param clones A list in which the i-th element contains the indices of all 
#' cells belonging to node \code{i} in \code{g}. Can be set to \code{NULL} if 
#' tree is a cell lineage tree.
#' @param e.length Vector containing the lenghts of the edges \code{E(g)}. If 
#' \code{NULL} (default) all edges are plotted with the same length (in y direction).
#' @param scale.width Parameter to tweak the position of nodes in direction of the
#' x axis.
#' @param axis Should a y-axis be plotted? Default is \code{FALSE}.
#' @param label.length Number of cell labels to be printed as node labels in a 
#' single row. Can be \code{"max"} or an integer > 0.
#' @param ... Additional plotting parameters. See \link[igraph]{igraph.plotting}
#' for the complete list.
#' @param f.x Fraction by which x axis range is extended.
#' @param f.y Fraction by which y axis range is extended.
#' @param v.label.cex cex value for vertex label.
#' @note setting \code{label.length>1} can lead to inaccurate edge length 
#' representation
#' @examples 
#' ## simulate example data set
#' dat <- simulateData(N.cells=20,N.clones=5)
#' ## plot tree
#' plotTree(tree=dat$g,clones=dat$clones,e.length=table(dat$theta),axis=TRUE)
#' ## plot tree with node sizes corresponding to sizes of subpopulations
#' plotTree(tree=dat$g,e.length=table(dat$theta),
#'          vertex.size=sapply(dat$clones,length),
#'          axis=TRUE,vertex.label=NA,edge.arrow.mode='-')
plotTree <- function(tree,clones=NULL,e.length=NULL,scale.width=NULL,axis=FALSE,
                     label.length="max",f.x=0.1,f.y=0.1,v.label.cex=1,...) {
  if (is.vector(tree)) {
    g <- igraph::graph.edgelist(el=cbind(tree+1,(1:length(tree))+1))
  } else if (igraph::is.igraph(tree)) {
    g <- tree
  } else {
    stop("tree has unknown input format. Should be in vector format or an igraph
         object")
  }
  if (!is.null(clones)) {
    if(length(clones)!=igraph::vcount(g)) {
      stop(paste0("List of clones does not match tree.
                  Has to have length vcount(g)=",igraph::vcount(g),'.'))
    }
    if (label.length=="max") {
      igraph::V(g)$label <- c('N',sapply(clones[-1],function(x) toString(sort(x))))
    } else {
      igraph::V(g)$label <- c('N',sapply(clones[-1],function(x) {
        x <- sort(x)
        y <- vector()
        while (length(x)>label.length) {
          y <- c(y,x[1:label.length],'\n')
          x <- x[-(1:label.length)]
        }
        if (length(x)>0) {
          y <- c(y,x)
        }
        y <- toString(y)
        gsub(' \n,',replacement = '\n',x = y)
      } 
      ))
    }
  } else {
    igraph::V(g)$label <- c('N',1:(igraph::vcount(g)-1))
  }
  
  g.orig <- g
  
  nv <- igraph::vcount(g)
  layout <- igraph::layout.reingold.tilford(g)
  tree.depth <- max(layout[,2])
  leaf.nodes <- (1:nv)[igraph::degree(g,mode="out")==0]
  leaf.depth <- igraph::shortest.paths(g,v = 1,to = leaf.nodes)
  ## remove leaves with maximum depth
  leaf.nodes <- leaf.nodes[leaf.depth<tree.depth]
  leaf.depth <- leaf.depth[leaf.depth<tree.depth]
  counter <- nv
  if (length(leaf.nodes)>=1) {
    for (i in 1:length(leaf.nodes)) {
      ## add nodes and edges so that every leaf node has maximum depth
      delta <- tree.depth-leaf.depth[i]
      g <- g+delta
      #     g <- g+path(c(leaf.nodes[i],counter+1:delta))
      if (delta==1) {
        g[from=c(leaf.nodes[i]),
          to=counter+1] <- TRUE
      } else {
        g[from=c(leaf.nodes[i],counter+(1:(delta-1))),
          to=counter+(1:delta)] <- TRUE
      }
      counter <- counter+delta
    }
  }
  ## get new layout matrix.
  layout.new <- igraph::layout.reingold.tilford(g)[1:nv,]
  if (!is.null(e.length)) {
    el <- igraph::get.edgelist(g.orig)  
    Pred <- transitiveClosure(el, returnAdjMat = TRUE)
    for (i in 1:nrow(el)) {
      ## update y coordinates
      layout.new[Pred[el[i,2],]==1,2] <- layout.new[Pred[el[i,2],]==1,2]-e.length[i]+1
    }
  }
  if (!is.null(scale.width)) {
    layout.new[,1] <- layout.new[,1]*scale.width
  }
  ## set y value of normal to 0
  layout.new[,2] <- layout.new[,2]-max(layout.new[,2])
  if (is.null(clones)) {
    # http://stackoverflow.com/questions/14472079/match-vertex-size-to-label-
    # size-in-igraph/19097133
    plot(0, type="n", ann=FALSE, axes=FALSE, xlim=extendrange(layout.new[,1]), 
         ylim=extendrange(layout.new[,2]))
    if (axis) {
      axis(2)
    }
    igraph::plot.igraph(g.orig, layout=layout.new, rescale=FALSE, add=TRUE,...)
  } else {
    plot(0, type="n", ann=FALSE, axes=FALSE, xlim=extendrange(layout.new[,1],f=f.x), 
         ylim=extendrange(layout.new[,2],f=f.y))
    if (axis) {
      axis(2)
    }
    igraph::plot.igraph(g.orig, layout=layout.new, rescale=FALSE, add=TRUE,
                        vertex.shape="rectangle",
                        vertex.size=(strwidth(igraph::V(g.orig)$label) + strwidth("oo")) * 90 * v.label.cex,
                        vertex.size2=(strheight(igraph::V(g.orig)$label) + strheight("o")) * 100 * v.label.cex,
                        vertex.label.cex=v.label.cex,
                        ...)
  }  
}
  
# Function for careful resampling
# 
# @param x Vector that is being resampled
# @param ... Additional arguments passed to function sample.int.
# @seealso \code{\link[base]{sample.int}}
# @note Base function sample can cause problems if vector x has length 1.
resample2 <- function(x, ...) x[sample.int(length(x), ...)] ## careful sampling


#' Simulates a data set
#' 
#' \code{simulateData} simulates a tree structure and a corresponding data set 
#' of observed genotypes.
#' 
#' @export
#' @param N.cells Integer. Number of cells to simulate (not including the root).
#' Default is 20.
#' @param N.normalContam Integer. Number of cells that are non-tumour cells, i.e.
#' normal contamination. Has to be smaller than N.cells. Default is zero.
#' @param N.clones Integer. Number of clones to simulate (including N.unobs but 
#' not including the root). Must satisfy \eqn{N.clones+N.normalContam \leq N.cells}. 
#' If \eqn{N.clones=N.cells}, a cell lineage tree is simulated (default).
#' @param N.unobs Integer. Number of unobserved clones. N.clones has to be
#' so large that there exists a tree with N.clone+1 nodes and N.unobs clones with
#' at least two children. Default is zero.
#' @param N.sites Integer. Number of mutation sites to simulate. Default is 300.
#' @param FPR False positive rate. (Single value, default 0.03)
#' @param FNR False negative rate. (Single value, default 0.2)
#' @param p.missing Fraction of missing values in data set. Default is 0.2.
#' @param randomizeOrder Logical. Should order of data set columns be 
#' randomized? Default is FALSE.
#'  
#' @details Data is simulated so that all cells belonging to one clone have the
#' same true genotype. Every clone contains at least one cell. If \eqn{N.cells>
#' N.normalContam+N.clones}, the remaining cells are assigned to clones in a 
#' rich-get-richer manner, to generate clones of different sizes.
#' 
#' @return List containing \describe{
#' \item{\code{Data}}{Matrix of observed genotypes with dimensions 
#' \code{N.sites x N.cells}.}
#' \item{\code{theta}}{Occurrence parameter.}
#' \item{\code{gtyp}}{True genotypes of clones (mutations x clones).}
#' \item{\code{g}}{Igraph object of simulated tree structure where node i 
#' corresponds to entry i of list \code{clones}.}
#' \item{\code{clones}}{List of clones.} 
#' \item{\code{FPR}, \code{FNR}}{Parameters used for 
#' simulation.} 
#' \item{\code{FPR.effective}}{Effective false positive rate. Can differ from FPR
#' due to the addition of false positives to sites in which all 1s got lost because
#' of missing values and false negatives.}
#' \item{\code{N.fp}, \code{N.fn}}{Total number of
#' false positives and false negatives in the data set.}
#' }
#' 
#' @note All indices in the output are 1-based, i.e. normal root has index 1.
#' @note Missing values are encoded as 2.
#' @examples
#' dat <- simulateData()
simulateData <- function(N.cells=20,
                         N.normalContam=0, 
                         N.clones=N.cells,
                         N.unobs=0,
                         N.sites=300,
                         FPR=0.03,
                         FNR=0.2,
                         p.missing=0.2,
                         randomizeOrder=FALSE) {
  
  ## Start input test
  is.wholenumber <- function(x, tol = .Machine$double.eps^0.5)  {
    if (!is.numeric(x)) {
      return(FALSE)
    }
    abs(x - round(x)) < tol
  }
  
  
  if (!is.wholenumber(N.cells)||N.cells<4) {
    stop("N.cells must be an integer greater than 4.")
  }
  
  if (!is.wholenumber(N.normalContam)||N.normalContam<0) {
    stop("N.normalContam must be an integer greater than or equal to 0.")
  }
  
  if (!is.wholenumber(N.unobs)||N.unobs<0||N.unobs>N.clones) {
    stop("N.unobs must be an integer greater than or equal to 0 and much smaller
         than N.clones.")
  }
  
  if (!is.wholenumber(N.clones)||N.clones<=0) {
    stop("N.clones has to be an integer greater than 0.")
  } else if (N.clones+N.normalContam-N.unobs >N.cells) {
    stop("N.clones + normalConam must be smaller than or equal to N.cells.")
  }

  if (!is.wholenumber(N.sites)|N.sites < 2) {
    stop("N.sites must be an integer greater than 1.")
  }
  
  if (!(FPR>=0&FPR<1)) {
    stop("FPR must be a numeric value between 0 and 1.")
  }
  
  if (!(FNR>=0&FNR<1)) {
    stop("FNR must be a numeric value between 0 and 1.")
  }
  
  if (!(p.missing>=0&p.missing<1)) {
    stop("p.missing must be a numeric value between 0 and 1.")
  }
  
  ## End input test
  
  ## GENERATE TREE ##
  
  ## calculate number of remaining cells
  N.other <-  N.cells-N.normalContam-N.clones+N.unobs
    
  ## generate tree structure
  if (N.unobs==0) {
    if (N.clones==1) {
      el <- matrix(ncol=2,nrow=0) ## normal is added later
    } else if (N.clones==2) {
      el <- rbind(1:2)
    } else {
      el <- cbind(from=c(1,sapply(3:N.clones,function(x) resample2(1:(x-1),1))),
                  to=(2:N.clones))
    }
    unobs.indx <- NULL
  } else {
    if (N.clones<=2||(N.clones==3&N.unobs>1)) {
      stop("Number of clones to small for number of unobserved nodes.")
    } 
    generateTree <- TRUE
    while (generateTree) {
      el <- cbind(from=c(1,sapply(3:N.clones,function(x) resample2(1:(x-1),1))),
                  to=(2:N.clones))
      ## if at least N.unobs clones have more than two children.
      if (sum(table(el[,1])>=2)>=N.unobs) {
        ## choose unobserved clones randomly from all clones with two children
        ## and make indx 1 based
        unobs.indx <- sample(as.numeric(names(which(table(el[,1])>=2))),
                             N.unobs,replace=FALSE)+1
        ## exit loop
        generateTree <- FALSE
      }
    }
  }  
  
  ## add normal to edge list and make it 1 based
  el <- rbind(c(0,1), ## edge from normal to founder cell
              el) + 1
  
  ## set up list of clones
  clones <- lapply(1:(N.clones+1),function(x) logical())
  ## add normal conamination to root clone
  if (N.normalContam>0) {
    clones[[1]] <- 1:N.normalContam
  } 
  ## add one cell to every observed non-root clone
  clones[-c(1,unobs.indx)] <- as.list((1:(N.clones-N.unobs))+N.normalContam)
  
  if (N.other>0) {
    ## add remaining cells to tree in a rich get richer manner but not to root
    if (N.clones==1) {
      ## add all remaining cells to single clone
      clones[[2]] <- c(clones[[2]],(N.normalContam+N.clones-N.unobs+1):N.cells)
    } else {
      ## add remaining cells to tree in a rich get richer manner
      for (i in (N.normalContam+N.clones-N.unobs+1):N.cells) {
        idx <- sample(2:length(clones),1,prob = sapply(clones[-1],length)/
                        sum(sapply(clones[-1],length)))
        clones[[idx]] <- c(clones[[idx]],i)
      }
    }
  }  
  ## transitive closure of generated tree
  Pred <- transitiveClosure(el = el,returnAdjMat = TRUE)
  
  ## GENERATE DATA ##
  theta <- sample(1:N.clones,N.sites,replace=TRUE)+1 ## no mutations in normal
  
  ## true Genotypes of cancer clones
  gtyp <- Pred[theta,]
  colnames(gtyp) <- 1:(N.clones+1)
  
  ## observed data
  clone.of.cell <- rep(1:length(clones),sapply(clones,length))[order(unlist(clones))]
  D <- D.true <- gtyp[,clone.of.cell]
  colnames(D) <- 1:N.cells
  
  ## missing values
  if (p.missing>0) {
    indx.missing <- sample((1:prod(dim(D))),ceiling(prod(dim(D))*p.missing),
                           replace=FALSE)
    D[indx.missing] <- 2
  }
  
  ## Introduce false positives & negatives
  indx.positive <- which(D==1)
  indx.negative <- which(D==0)
  
  N.fp <- floor(length(indx.negative)*FPR)
  N.fn <- ceiling(length(indx.positive)*FNR)
  
  indx.fp <- sample(indx.negative,N.fp,replace=FALSE)
  indx.fn <- sample(indx.positive,N.fn,replace=FALSE)
  
  D[indx.fp] <- 1
  D[indx.fn] <- 0
  
  ## add false positives to sites that end up having no 1s at all
  indx.zero <- which(rowSums(D)==0)
  if (length(indx.zero)>0) {
    D[indx.zero,sample(1:ncol(D),length(indx.zero),replace = TRUE)] <- 1
    FPR.effective <- sum(D[D.true==0]==1,na.rm=TRUE)/sum(D.true==0)
  } else {
    FPR.effective <- FPR
  }
  
  ## calculate number of false positives and false negatives
  N.fp=sum(D.true==0&D==1,na.rm=TRUE)
  N.fn=sum(D.true==1&D==0,na.rm=TRUE)
  
  ## igraph of true tree
  g <- igraph::graph.edgelist(el,directed=TRUE)
  igraph::V(g)$name <- 1:max(el)
  
  # randomize columns of data matrix to avoid biases in simulation studies
  if (randomizeOrder) {
    o <- sample(2:ncol(D),(ncol(D)-1),replace=FALSE)
    D <- D[,c(1,o)]
  }
  
  return(list(D=D,
              theta=theta,
              gtyp=gtyp,
              g=g,
              clones=clones,
              FPR=FPR,
              FNR=FNR,
              FPR.effective=FPR.effective,
              N.fp=N.fp,
              N.fn=N.fn,
              N.fp.sites=length(indx.zero)))
  
}

#' Improved function to simulate a data set
#' 
#' \code{simulateData2} simulates a tree structure and a corresponding data set 
#' of observed genotypes with more accurate error rates 
#' 
#' @export
#' @param N.cells Integer. Number of cells to simulate (not including the root).
#' Default is 20.
#' @param N.normalContam Integer. Number of cells that are non-tumour cells, i.e.
#' normal contamination. Has to be smaller than N.cells. Default is zero.
#' @param N.clones Integer. Number of clones to simulate (including N.unobs but 
#' not including the root). Must satisfy \eqn{N.clones+N.normalContam \leq N.cells}. 
#' If \eqn{N.clones=N.cells}, a cell lineage tree is simulated (default).
#' @param N.unobs Integer. Number of unobserved clones. N.clones has to be
#' so large that there exists a tree with N.clone+1 nodes and N.unobs clones with
#' at least two children. Default is zero.
#' @param N.sites Integer. Number of mutation sites to simulate. Default is 300.
#' @param FPR False positive rate. (Single value, default 0.03)
#' @param FNR False negative rate. (Single value, default 0.2)
#' @param p.missing Fraction of missing values in data set. Default is 0.2.
#' @param randomizeOrder Logical. Should order of data set columns be 
#' randomized? Default is FALSE.
#'  
#' @details Data is simulated so that all cells belonging to one clone have the
#' same true genotype. Every clone contains at least one cell. If \eqn{N.cells>
#' N.normalContam+N.clones}, the remaining cells are assigned to clones in a 
#' rich-get-richer manner, to generate clones of different sizes.
#' 
#' @return List containing \describe{
#' \item{\code{Data}}{Matrix of observed genotypes with dimensions 
#' \code{N.sites x N.cells}.}
#' \item{\code{theta}}{Occurrence parameter.}
#' \item{\code{gtyp}}{True genotypes of clones (mutations x clones).}
#' \item{\code{g}}{Igraph object of simulated tree structure where node i 
#' corresponds to entry i of list \code{clones}.}
#' \item{\code{clones}}{List of clones.} 
#' \item{\code{FPR}, \code{FNR}}{Parameters used for 
#' simulation.} 
#' \item{\code{N.fp}, \code{N.fn}}{Total number of
#' false positives and false negatives in the data set.}
#' }
#' 
#' @note All indices in the output are 1-based, i.e. normal root has index 1.
#' @note Missing values are encoded as 2.
#' @examples
#' dat <- simulateData()
simulateData2 <- function(N.cells=20,
                          N.normalContam=0, 
                          N.clones=N.cells,
                          N.unobs=0,
                          N.sites=300,
                          FPR=0.03,
                          FNR=0.2,
                          p.missing=0.2,
                          randomizeOrder=FALSE) {
  
  ## Start input test
  is.wholenumber <- function(x, tol = .Machine$double.eps^0.5)  {
    if (!is.numeric(x)) {
      return(FALSE)
    }
    abs(x - round(x)) < tol
  }
  
  
  if (!is.wholenumber(N.cells)||N.cells<4) {
    stop("N.cells must be an integer greater than 4.")
  }
  
  if (!is.wholenumber(N.normalContam)||N.normalContam<0) {
    stop("N.normalContam must be an integer greater than or equal to 0.")
  }
  
  if (!is.wholenumber(N.unobs)||N.unobs<0||N.unobs>N.clones) {
    stop("N.unobs must be an integer greater than or equal to 0 and much smaller
         than N.clones.")
  }
  
  if (!is.wholenumber(N.clones)||N.clones<=0) {
    stop("N.clones has to be an integer greater than 0.")
  } else if (N.clones+N.normalContam-N.unobs >N.cells) {
    stop("N.clones + normalConam must be smaller than or equal to N.cells.")
  }
  
  if (!is.wholenumber(N.sites)|N.sites < 2) {
    stop("N.sites must be an integer greater than 1.")
  }
  
  if (!(FPR>=0&FPR<1)) {
    stop("FPR must be a numeric value between 0 and 1.")
  }
  
  if (!(FNR>=0&FNR<1)) {
    stop("FNR must be a numeric value between 0 and 1.")
  }
  
  if (!(p.missing>=0&p.missing<1)) {
    stop("p.missing must be a numeric value between 0 and 1.")
  }
  
  ## End input test
  
  ## GENERATE TREE ##
  
  ## calculate number of remaining cells
  N.other <-  N.cells-N.normalContam-N.clones+N.unobs
  
  ## generate tree structure
  if (N.unobs==0) {
    if (N.clones==1) {
      el <- matrix(ncol=2,nrow=0) ## normal is added later
    } else if (N.clones==2) {
      el <- rbind(1:2)
    } else {
      el <- cbind(from=c(1,sapply(3:N.clones,function(x) resample2(1:(x-1),1))),
                  to=(2:N.clones))
    }
    unobs.indx <- NULL
  } else {
    if (N.clones<=2||(N.clones==3&N.unobs>1)) {
      stop("Number of clones to small for number of unobserved nodes.")
    } 
    generateTree <- TRUE
    while (generateTree) {
      el <- cbind(from=c(1,sapply(3:N.clones,function(x) resample2(1:(x-1),1))),
                  to=(2:N.clones))
      ## if at least N.unobs clones have more than two children.
      if (sum(table(el[,1])>=2)>=N.unobs) {
        ## choose unobserved clones randomly from all clones with two children
        ## and make indx 1 based
        unobs.indx <- sample(as.numeric(names(which(table(el[,1])>=2))),
                             N.unobs,replace=FALSE)+1
        ## exit loop
        generateTree <- FALSE
      }
    }
  }  
  
  ## add normal to edge list and make it 1 based
  el <- rbind(c(0,1), ## edge from normal to founder cell
              el) + 1
  
  ## set up list of clones
  clones <- lapply(1:(N.clones+1),function(x) logical())
  ## add normal conamination to root clone
  if (N.normalContam>0) {
    clones[[1]] <- 1:N.normalContam
  } 
  ## add one cell to every observed non-root clone
  clones[-c(1,unobs.indx)] <- as.list((1:(N.clones-N.unobs))+N.normalContam)
  
  if (N.other>0) {
    ## add remaining cells to tree in a rich get richer manner but not to root
    if (N.clones==1) {
      ## add all remaining cells to single clone
      clones[[2]] <- c(clones[[2]],(N.normalContam+N.clones-N.unobs+1):N.cells)
    } else {
      ## add remaining cells to tree in a rich get richer manner
      for (i in (N.normalContam+N.clones-N.unobs+1):N.cells) {
        idx <- sample(2:length(clones),1,prob = sapply(clones[-1],length)/
                        sum(sapply(clones[-1],length)))
        clones[[idx]] <- c(clones[[idx]],i)
      }
    }
  }  
  ## transitive closure of generated tree
  Pred <- transitiveClosure(el = el,returnAdjMat = TRUE)
  
  ## GENERATE DATA ##
  theta <- sample(1:N.clones,N.sites,replace=TRUE)+1 ## no mutations in normal
  
  ## true Genotypes of cancer clones
  gtyp <- Pred[theta,]
  colnames(gtyp) <- 1:(N.clones+1)
  
  ## observed data
  clone.of.cell <- rep(1:length(clones),sapply(clones,length))[order(unlist(clones))]
  D <- D.true <- gtyp[,clone.of.cell]
  colnames(D) <- 1:N.cells
  
  ## Introduce false missing values, positives & negatives
  D.tmp <- D
  D.tmp2 <- matrix(TRUE,nrow = nrow(D), ncol = ncol(D))
  ## keep at least one mutant entry per site
  for (i in 1:nrow(D.tmp)) {
    print(i)
    idx.keepOne <- sample(which(D.tmp[i,]==1),1)
    D.tmp[i,idx.keepOne] <- 0
    D.tmp2[i,idx.keepOne] <- FALSE
  }
  
  ## missing values
  if (p.missing>0) {
    
    N.missing <- ceiling(prod(dim(D))*p.missing)
    if (N.missing>sum(D.tmp2)) {
      stop("Decrease p.missing.")
    }
    indx.missing <- sample(which(D.tmp2),N.missing,
                           replace=FALSE)
    D[indx.missing] <- 2
    D.tmp[indx.missing] <- 2
  }

  indx.positive <- which(D.tmp==1)
  indx.negative <- which(D==0)
  
  N.fp <- floor(length(indx.negative)*FPR)
  N.fn <- ceiling(sum(D==1)*FNR)
  
  indx.fp <- sample(indx.negative,N.fp,replace=FALSE)
  indx.fn <- sample(indx.positive,N.fn,replace=FALSE)
  
  D[indx.fp] <- 1
  D[indx.fn] <- 0
  
  ## only select sites that have at least one mutant entry
  FPR.effective <- sum(D[D.true==0&D!=2]==1,na.rm=TRUE)/sum(D.true==0&D!=2)
  FNR.effective <- sum(D[D.true==1&D!=2]==0,na.rm=TRUE)/sum(D.true==1&D!=2)
  
  ## calculate number of false positives and false negatives
  N.fp=sum(D.true==0&D==1,na.rm=TRUE)
  N.fn=sum(D.true==1&D==0,na.rm=TRUE)
  
  ## igraph of true tree
  g <- igraph::graph.edgelist(el,directed=TRUE)
  igraph::V(g)$name <- 1:max(el)
  
  # randomize columns of data matrix to avoid biases in simulation studies
  if (randomizeOrder) {
    o <- sample(2:ncol(D),(ncol(D)-1),replace=FALSE)
    D <- D[,c(1,o)]
  }
  
  return(list(D=D,
              theta=theta,
              gtyp=gtyp,
              g=g,
              clones=clones,
              FPR=FPR,
              FNR=FNR,
              FPR.effective=FPR.effective,
              FNR.effective=FNR.effective,
              N.fp=N.fp,
              N.fn=N.fn))
  
  }


#' Transitive closure of a graph
#' 
#' \code{transitiveClosure} calculates the transitive closure of a given tree 
#' using the RBGL implementation.
#' 
#' @export
#' @param el An edge list. A numeric two-column matrix in which each row defines
#' one edge.
#' @param returnAdjMat Logical. Should an adjacency matrix (default=TRUE) or an
#' edge list be returned?
#' @return The transitive closure of the given tree in form of an adjacency 
#' matrix or an edge list.
#'
transitiveClosure <- function(el, returnAdjMat = TRUE) {
  if (ncol(el)!=2) {
    stop("Edgelist has wrong format. See ?transitiveClosure for help.")
  }
  ## edgelist to adjacency matrix
  am <- matrix(0,nrow=max(el),ncol=max(el)) ## max(el)=number of vertices
  am[el] <- 1  
  new.am <- ggm::transClos(amat = am) 
  
  if (returnAdjMat) {
    diag(new.am) <- 1
    return(new.am)
  } else {
    ## return new el
    new.el <- which(new.am==1,arr.ind = TRUE)
    colnames(new.el) <- c('from','to')
    return(new.el)
  }
  
}
# transitiveClosure <- function(el,returnAdjMat=TRUE) {
#   if (ncol(el)!=2) {
#     stop("Edgelist has wrong format. See ?transitiveClosure for help.")
#   }
#   
#   nv <- max(el) ## number of vertices
#   em <- t(el) ## edge matrix
#   ne <- ncol(em) ## number of edges
#   
#   ## Find transitive closure using RBGL package 
#   # algorithm uses 0-based node indices
#   ans <- .Call("BGL_transitive_closure_D", as.integer(nv), 
#                as.integer(ne), as.integer(em - 1), PACKAGE = "RBGL")
#   new.el <- t(ans[[2]]) + 1 ## make node indices 1-based
#   
#   if (returnAdjMat) {
#     new.adjMat <- matrix(0,nrow=nv,ncol=nv)
#     new.adjMat[new.el] <- 1
#     diag(new.adjMat) <- 1
#     return(new.adjMat)
#   } else {
#     ## return el
#     colnames(new.el) <- c('from','to')
#     return(new.el)
#   }
#   
# }

################################### v-Measure ##################################
## subfunctions are not exported

# Contingency table of two clustering solutions
# 
# Used as subfunction to calculate V-measure
# 
# @inheritParams vMeasure
# @return A Contingency matrix of true clusters x predicted clusters
# @seealso \code{\link{vMeasure}}
contingencyTable <- function(trueClusters,predClusters) {
  true <- data.frame(cell=unlist(trueClusters),
                     true=rep(1:length(trueClusters),sapply(trueClusters,length)))
  pred <- data.frame(cell=unlist(predClusters),
                     pred=rep(1:length(predClusters),sapply(predClusters,length)))
  A <- table(merge(true,pred,by.y='cell',by.x='cell')[,-1])
  return(A)
}

# Subfunction for calculating V-measure
# 
# @param A Contingency matrix of true clusters x predicted clusters
H_C <- function(A) {
  N=sum(A)
  -sum(apply(A,1,sum)/N * log( apply(A,1,sum)/N ))
}

# Subfunction for calculating V-measure
# 
# @param A Contingency matrix of true clusters x predicted clusters
H_CK <- function(A) {
  N=sum(A)
  A_norm <- log(apply(A,2,function(x) x/sum(x)))
  A_norm[A==0] <- 0
  -sum(A/N * A_norm)
}

# Subfunction for calculating V-measure (homogeneity)
# 
# @param A Contingency matrix of true clusters x predicted clusters
homogeneity <- function(A) {
  if (H_C(A)==0){
    return(1)
  }
  1-H_CK(A)/H_C(A)
}

# Subfunction for calculating V-measure
# 
# @param A Contingency matrix of true clusters x predicted clusters
H_K <- function(A) {
  N=sum(A)
  -sum(apply(A,2,sum)/N * log( apply(A,2,sum)/N ))
}

# Subfunction for calculating V-measure
# 
# @param A Contingency matrix of true clusters x predicted clusters
H_KC <- function(A) {
  N=sum(A)
  A_norm <- log(t(apply(A,1,function(x) x/sum(x))))
  A_norm[A==0] <- 0
  -sum(A/N *A_norm)
}

# Subfunction for calculating V-measure (completeness)
# 
# @param A Contingency matrix of true clusters x predicted clusters
completeness <- function(A) {
  if (H_K(A)==0) {
    return(1)
  }
  1-H_KC(A)/H_K(A)
}

#' V-Measure
#' 
#' Calculates the v-measure of two clustering solutions. The v-measure is an 
#' entropy-based external cluster evaluation measure.
#' 
#' @export
#' @param trueClusters True clusters of cells. List in which each element 
#' corresponds to a clone and contains the indices of the cells corresponding to
#' that clone
#' @param predClusters Predicted clusters of cells. Same format as 
#' \code{trueClusters}.
#' @return v-Measure of a prediction given the true solution.
#' @references Rosenberg, A. and Hirschberg, J. "V-Measure: A Conditional 
#' Entropy-Based External Cluster Evaluation Measure." \emph{EMNLP-CoNLL}. Vol. 
#' 7. 2007.
#' @examples
#' ## simulate example data set
#' dat <- simulateData(N.cells=20,N.clones=5)
#' ## initialize oncoNEM object
#' oNEM <- oncoNEM(dat$D,dat$FPR,dat$FNR)
#' ## run initial search until best tree has not changed for 100 steps
#' oNEM$search(delta = 100)
#' ## cluster tree
#' oncoTree <- clusterOncoNEM(oNEM,epsilon=10)
#' ## Compare inferred tree to ground truth
#' vMeasure(trueClusters=dat$clones,predClusters=oncoTree$clones)
vMeasure <- function(trueClusters,predClusters) {
  
  A <- contingencyTable(trueClusters,predClusters)
  
  h <- homogeneity(A)
  c <- completeness(A)
  
  beta=1 ## equal weights for completeness and homogeneity
  
  ## v-measure
  ((1+beta)*h*c)/((beta*h)+c)
  
}

################################################################################

#' Change the cell labels of a given tree 
#' 
#' The cells of an inferred tree are labeled from 1:ncol(Data). If for the data 
#' simulation the parameter \code{randomizeOrder} is \code{TRUE}, the labels 
#' of inferred and true tree do not match. This function allows to relabel the 
#' cells in the clone list of the inferred tree to match the original ones defined
#' by colnames(Data). This is needed for performance assessment.
#' 
#' @export
#' @param clones List of clones, i.e. oncoNEM$clones
#' @param labels New labels. I^{th} entry is new label of cell that currently has label i.
#' Choose new labels to be \code{as.numeric(colnames(oncoNEM$Data))}.
#' @return List of clones where cells are relabeled.
relabelCells <- function(clones,labels) {
  labels <- cbind(1:length(labels),labels)
  clones <- lapply(clones,function(x) sapply(x,function(xi) if (any(labels[,1]==xi)) {
    labels[labels[,1]==xi,2]
  } else { ## unobserved cell
    xi
  }))
  return(clones)
}

