library(testthat)
library(muscat)

test_check("muscat")
