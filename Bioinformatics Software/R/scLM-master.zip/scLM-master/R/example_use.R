
## library(scLM)

#' load the example data
## data("example1")
## data("example1.member")
##data("example2")
##data("example2.member")

## result1 <- Multi_NB(datalist=example1, N=3, K=nrow(example1[[1]]))

#' calculate the ARI index
## library(clues)
## adjustedRand(result1$clusters,example1.member)
