.onLoad <- function(lib, pkg) {
  library.dynam("scLM", pkg, lib)
}
