#' sake.
#'
#' This tool can help you quickly navigate through the expression profile,
#' Using NMF method for unsupervised clustering.
#' @name sake
#' @docType package
NULL

