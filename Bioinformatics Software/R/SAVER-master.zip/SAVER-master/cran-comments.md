## Submission
This is a submission of an update (1.1.3) to the SAVER package. 

## Test environments
* local Windows 10 install, R 4.2.0
* R-hub Ubuntu 20.04.1 LTS, R-devel, GCC (ubuntu-gcc-devel)

## R CMD check results

There were no ERRORs, WARNINGs, or NOTEs.
