# install the required R packages for the demos
install.packages("Rcpp",dependencies=TRUE)
install.packages("Matrix",dependencies=TRUE)
install.packages("pracma",dependencies=TRUE)
install.packages("RcppAnnoy",dependencies=TRUE)
install.packages("RSpectra",dependencies=TRUE)
install.packages("igraph",dependencies=TRUE)
