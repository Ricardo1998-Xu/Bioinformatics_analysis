---
name: "\U0001F4DADocumentation"
about: An issue related to documentation at https://satijalab.org/seurat/
title: ''
labels: documentation
assignees: ''

---

<!-- A clear description of what content at https://satijalab.org/seurat or in the Seurat function man pages is an issue. -->
