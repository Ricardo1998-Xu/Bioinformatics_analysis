library(testthat)
library(iasva)

test_check("iasva")