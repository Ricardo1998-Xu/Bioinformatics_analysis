var searchData=
[
  ['size',['size',['../structUnitigMapBase.html#adf6bc2dfe176302491c81142fc2e84cc',1,'UnitigMapBase']]],
  ['strand',['strand',['../structUnitigMapBase.html#a6de6f4a1ccef220e84d097bc3ef0fb3f',1,'UnitigMapBase']]]
];
