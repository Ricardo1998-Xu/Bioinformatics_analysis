var searchData=
[
  ['dataaccessor',['DataAccessor',['../classDataAccessor.html#a0c30e8dfb40ff350083dd0822082dd66',1,'DataAccessor']]]
];
