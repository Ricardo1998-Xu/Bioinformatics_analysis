var searchData=
[
  ['ccdbg_5fbuild_5fopt',['CCDBG_Build_opt',['../structCCDBG__Build__opt.html',1,'']]],
  ['ccdbg_5fdata_5ft',['CCDBG_Data_t',['../classCCDBG__Data__t.html',1,'']]],
  ['cdbg_5fbuild_5fopt',['CDBG_Build_opt',['../structCDBG__Build__opt.html',1,'']]],
  ['cdbg_5fdata_5ft',['CDBG_Data_t',['../classCDBG__Data__t.html',1,'']]],
  ['cdbg_5fdata_5ft_3c_20dataaccessor_3c_20unitig_5fdata_5ft_20_3e_2c_20datastorage_3c_20unitig_5fdata_5ft_20_3e_20_3e',['CDBG_Data_t&lt; DataAccessor&lt; Unitig_data_t &gt;, DataStorage&lt; Unitig_data_t &gt; &gt;',['../classCDBG__Data__t.html',1,'']]],
  ['clear',['clear',['../classCCDBG__Data__t.html#adcdd42b81067d6095534f53b09c24aac',1,'CCDBG_Data_t::clear()'],['../classColoredCDBG.html#aa366d5e47c978119a20ec9494d3f2ad2',1,'ColoredCDBG::clear()'],['../classUnitigColors.html#a5a2723ca4914c4db05630fef8fa1e665',1,'UnitigColors::clear()'],['../classCDBG__Data__t.html#ad3ee42fef3155251e54886f3649f72a2',1,'CDBG_Data_t::clear()'],['../classCompactedDBG.html#ac85b803c8f7527ed3c68054b77224d6d',1,'CompactedDBG::clear()'],['../classDataAccessor.html#a8a0c9cd4d31f8c7b08dcb06e420ad202',1,'DataAccessor::clear()']]],
  ['cliptips',['clipTips',['../structCDBG__Build__opt.html#a7e916ec6f4674bf1239b64da22bac9ee',1,'CDBG_Build_opt']]],
  ['coloredcdbg',['ColoredCDBG',['../classColoredCDBG.html',1,'ColoredCDBG&lt; Unitig_data_t &gt;'],['../classColoredCDBG.html#aec6b5eb64fc7086bf81107849847071d',1,'ColoredCDBG::ColoredCDBG(int kmer_length=31, int minimizer_length=23)'],['../classColoredCDBG.html#a8d2b4c5690efe813b6229a6e22343335',1,'ColoredCDBG::ColoredCDBG(const ColoredCDBG &amp;o)'],['../classColoredCDBG.html#a757b4744f396052946171021db1a1fb6',1,'ColoredCDBG::ColoredCDBG(ColoredCDBG &amp;&amp;o)']]],
  ['coloredcdbg_2ehpp',['ColoredCDBG.hpp',['../ColoredCDBG_8hpp.html',1,'']]],
  ['colormax',['colorMax',['../classUnitigColors.html#aa68c4fe9877305f2db67cb998aabe6b6',1,'UnitigColors']]],
  ['colorset_2ehpp',['ColorSet.hpp',['../ColorSet_8hpp.html',1,'']]],
  ['compacteddbg',['CompactedDBG',['../classCompactedDBG.html',1,'CompactedDBG&lt; Unitig_data_t, Graph_data_t &gt;'],['../classCompactedDBG.html#ad6584f016b02651312c69ac444349bfe',1,'CompactedDBG::CompactedDBG(const int kmer_length=31, const int minimizer_length=23)'],['../classCompactedDBG.html#a84fbb8da0cf47e8cdf9cb60fb2eab0f0',1,'CompactedDBG::CompactedDBG(const CompactedDBG &amp;o)'],['../classCompactedDBG.html#ac93c3355910670b8244741b22baca929',1,'CompactedDBG::CompactedDBG(CompactedDBG &amp;&amp;o)']]],
  ['compacteddbg_2ehpp',['CompactedDBG.hpp',['../CompactedDBG_8hpp.html',1,'']]],
  ['compacteddbg_3c_20dataaccessor_3c_20unitig_5fdata_5ft_20_3e_2c_20datastorage_3c_20unitig_5fdata_5ft_20_3e_20_3e',['CompactedDBG&lt; DataAccessor&lt; Unitig_data_t &gt;, DataStorage&lt; Unitig_data_t &gt; &gt;',['../classCompactedDBG.html',1,'']]],
  ['concat',['concat',['../classCCDBG__Data__t.html#a0ce6821deb4441f8a7dd3d270ed8b3a6',1,'CCDBG_Data_t::concat()'],['../classCDBG__Data__t.html#a1d1eefcc5b100fbe000a5d70c4280aa3',1,'CDBG_Data_t::concat()'],['../classDataAccessor.html#a42b319c9eb802a3a9276227c00f69665',1,'DataAccessor::concat()']]],
  ['const_5fiterator',['const_iterator',['../classUnitigColors.html#ad4d35f8af18dfd9cad99e92ca2328fee',1,'UnitigColors::const_iterator()'],['../classCompactedDBG.html#a7725fc78ad52227df1f70d9b8f44622c',1,'CompactedDBG::const_iterator()']]],
  ['const_5funitigmap',['const_UnitigMap',['../CompactedDBG_8hpp.html#a631369597e56604279ba89a211c14fd0',1,'CompactedDBG.hpp']]],
  ['contains',['contains',['../classUnitigColors.html#a80198f26ea0b2d7c6c0378779c8e1810',1,'UnitigColors']]]
];
