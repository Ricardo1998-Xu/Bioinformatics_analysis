var searchData=
[
  ['infilenamebbf',['inFilenameBBF',['../structCDBG__Build__opt.html#aede0acb7ddd4b5bf7c6c539a86461d15',1,'CDBG_Build_opt']]],
  ['isempty',['isEmpty',['../structUnitigMapBase.html#ade629940b2611494dbf233cb1144da80',1,'UnitigMapBase::isEmpty()'],['../classUnitigColors.html#a8211a4472374f696433df782d30a8ee2',1,'UnitigColors::isEmpty()']]],
  ['isequal',['isEqual',['../classUnitigColors.html#a242276ed4b9198fd1718f0c2692af9e5',1,'UnitigColors']]],
  ['isinvalid',['isInvalid',['../classCompactedDBG.html#a5c2e72fe85306aa4ac190ae9b3e9b3a7',1,'CompactedDBG']]],
  ['iterator',['iterator',['../classCompactedDBG.html#af4a6df70628f698d9a2ee843b5359883',1,'CompactedDBG']]]
];
