/*
 * command_line_parser.h
 *
 *  Created on: Sep 14, 2015
 *      Author: cheng
 */

#ifndef COMMAND_LINE_PARSER_H_
#define COMMAND_LINE_PARSER_H_
#include "CLIArgs.h"
int parseCommandLine(CLIArgs& prog_params, int argc, char* argv[]);



#endif /* COMMAND_LINE_PARSER_H_ */
