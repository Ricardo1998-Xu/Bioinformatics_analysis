Configuration
----------------

Description of the fields for the config file is provided in
`dropEst/configs/config\_desc.xml <https://github.com/hms-dbmi/dropEst/blob/master/configs/config_desc.xml>`__.