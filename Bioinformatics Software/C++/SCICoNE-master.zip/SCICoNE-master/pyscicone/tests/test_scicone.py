from scicone import SCICoNE

def test_scicone():
    sci = SCICoNE()
    sci.run_tests()
