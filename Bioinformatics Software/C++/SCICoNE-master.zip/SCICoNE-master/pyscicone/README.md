This is a Python package to interact with SCICoNE. To use it, you must first install the SCICoNE binaries as indicated [here](../README.md).
