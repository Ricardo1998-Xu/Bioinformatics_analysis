// Copyright (c) 2015-2021 Daniel Cooke
// Use of this source code is governed by the MIT license that can be found in the LICENSE file.

#ifndef individual_reference_likelihood_model_hpp
#define individual_reference_likelihood_model_hpp

namespace octopus {


} // namespace octopus

#endif
