#include "config.h"
#include "gene_def.h"
#include "calc_function.h"


#ifndef INPUT_DATA
#define INPUT_DATA


void input_config(string filename);
void input_genes(string resultPath);
void input_annotation_gaf(string filename);

#endif

