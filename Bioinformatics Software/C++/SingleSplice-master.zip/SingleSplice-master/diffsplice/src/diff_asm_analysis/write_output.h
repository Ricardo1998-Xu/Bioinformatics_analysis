#include "config.h"
#include "calc_function.h"
#include "asm_def.h"

#ifndef WRITE_OUTPUT
#define WRITE_OUTPUT

void write_output(string resultPath);

#endif








