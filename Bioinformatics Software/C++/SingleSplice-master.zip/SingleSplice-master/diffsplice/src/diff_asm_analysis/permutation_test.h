#include "config.h"
#include "calc_function.h"

#ifndef PERMUTATION_TEST
#define PERMUTATION_TEST


bool diff_transcription_analysis_multi_class(double *statistics_expected_d, double* statistics_permuted_d[], string resultPath, string resultFileSuffix, double &s0);

#endif

