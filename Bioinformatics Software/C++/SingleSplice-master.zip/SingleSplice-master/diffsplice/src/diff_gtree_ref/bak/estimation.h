#ifndef ESTIMATION
#define ESTIMATION

extern unsigned long fragmentID_Cnt;

bool countGTree(GTvertex *rootVertex);

#endif

