library(testthat)
library(ivis)

test_check("ivis")
