.. GSEAPY documentation master file, created by
   sphinx-quickstart on Mon Feb  1 13:52:57 2016.
   You can adapt this file completely to your linking, but it should at least
   contain the root `toctree` directive.

Welcome to GSEAPY's documentation!
=====================================================

GSEAPY: Gene Set Enrichment Analysis in Python.
------------------------------------------------

.. image:: https://badge.fury.io/py/gseapy.svg
    :target: https://badge.fury.io/py/gseapy

.. image:: https://img.shields.io/conda/vn/bioconda/GSEApy.svg?style=plastic
    :target: http://bioconda.github.io

.. image:: https://github.com/zqfang/GSEApy/workflows/GSEApy/badge.svg?branch=master
    :target: https://github.com/zqfang/GSEApy/actions
    :alt: Action Status

.. image:: http://readthedocs.org/projects/gseapy/badge/?version=master
    :target: http://gseapy.readthedocs.io/en/master/?badge=master
    :alt: Documentation Status

.. image:: https://img.shields.io/badge/license-MIT-blue.svg
    :target:  https://img.shields.io/badge/license-MIT-blue.svg

.. image:: https://img.shields.io/pypi/pyversions/gseapy.svg
    :alt: PyPI - Python Version



**Release notes** : https://github.com/zqfang/GSEApy/releases 


Citation
------------------------------------
::

    Zhuoqing Fang, Xinyuan Liu, Gary Peltz, GSEApy: a comprehensive package for performing gene set enrichment analysis in Python, 
    Bioinformatics, 2022;, btac757, https://doi.org/10.1093/bioinformatics/btac757



Installation
------------------------------------------------

| Install gseapy package from bioconda or pypi.


.. code:: shell
   
   # if you have conda (MacOS_x86-64 and Linux only)
   $ conda install -c bioconda gseapy
  
   # or use pip to install the latest release
   $ pip install gseapy



GSEApy is a Python/Rust implementation of **GSEA** and wrapper for **Enrichr**. 
--------------------------------------------------------------------------------------------

GSEApy has multiple subcommands: ``gsea``, ``prerank``, ``ssgsea``, ``gsva``, ``replot`` ``enrichr``, ``biomart``.

1. The ``gsea`` module produces **GSEA** results.    
The input requries a txt file(FPKM, Expected Counts, TPM, et.al), a cls file, and gene_sets file in gmt format. 

2. The ``prerank`` module produces **Prerank tool** results.  
The input expects a pre-ranked gene list dataset with correlation values, which in .rnk format, and gene_sets file in gmt format.  ``prerank`` module is an API to `GSEA` pre-rank tools.

3. The ``ssgsea`` module performs **single sample GSEA(ssGSEA)** analysis.  
The input expects a gene list with expression values(same with ``.rnk`` file, and gene_sets file in gmt format. ssGSEA enrichment score for the gene set as described by `D. Barbie et al 2009 <http://www.nature.com/nature/journal/v462/n7269/abs/nature08460.html>`_.

4. The ``gsva`` module performs **GSVA** analysis, which described by `Hänzelmann et al <https://bmcbioinformatics.biomedcentral.com/articles/10.1186/1471-2105-14-7>`_.

5. The ``replot`` module reproduces GSEA desktop version results.  
The only input for GSEAPY is the location to GSEA Desktop output results.

6. The ``enrichr`` module enables you to perform gene set enrichment analysis using ``Enrichr`` API.
Enrichr is open source and freely available online at: http://amp.pharm.mssm.edu/Enrichr . It runs very fast and generates results in txt format.

7. The ``biomart`` module helps you convert gene ids using BioMart API.


GSEApy could be used for **RNA-seq, ChIP-seq, Microarry** data. It's used for convenient GO enrichments and produce **publishable quality figures** in python. 


The full ``GSEA`` is far too extensive to describe here; see
`GSEA  <http://www.broadinstitute.org/cancer/software/gsea/wiki/index.php/Main_Page>`_ documentation for more information. All files' formats for GSEApy are identical to ``GSEA`` desktop version. 



Why GSEAPY
-----------------------------------------------------

I would like to use Pandas to explore my data, but I did not find a convenient tool to
do gene set enrichment analysis in python. So, here are my reasons:

* **Ability to run inside python interactive console without having to switch to R!!!**
* User friendly for both wet and dry lab users.
* Produce or reproduce publishable figures.
* Perform batch jobs easy.
* Easy to use in bash shell or your data analysis workflow, e.g. snakemake.



.. toctree::
    :caption: Table of Contents
    :maxdepth: 1
    :numbered:
   
    introduction.rst
    gseapy_example.ipynb
    singlecell_example.ipynb
    gseapy_tutorial
    run.rst
    faq.rst
	



   
   


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


