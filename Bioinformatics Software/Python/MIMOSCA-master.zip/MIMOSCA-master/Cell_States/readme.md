This folder contains the a worked example of calculating cell states from a single cell dataset

It includes a 3hr LPS stimulated PMDC 10x dataset (~1300 cells), mm10.zip
