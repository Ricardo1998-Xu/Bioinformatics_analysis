# Contents

* iPython notebook containing example of fitting the MOI distribution (with data contained in the small_data folder)
* iPython notebook containing example of processing fastq files in counts table
* iPython notebook containing example of processing counts table into GBC/CBC dictionary
