# Contents

* An iPython notebook that compares population RNA-seq data of OST complex knockouts to our pilot data obtained using scRNA-seq

* An iPython notebook that serves to give rough back of the envelope calculations of scale for Perturb-seq

