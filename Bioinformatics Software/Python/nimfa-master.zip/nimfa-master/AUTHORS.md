.. -*- mode: rst -*-


This is a community effort, and as such many people have contributed
to it over the years.

History
-------

This project was started in 2011 as a Google Summer of Code project by
Marinka Zitnik.

People
------

The following people have been core contributors to Nimfa's development and maintenance:

* Yaroslav Halchenko
* Vamsi Krishna
* Mariano Tepper
* Marko Toplak
* Marinka Zitnik <http://cs.stanford.edu/~marinka>
* Blaz Zupan
