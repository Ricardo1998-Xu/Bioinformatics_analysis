.. automodule:: nimfa.models.nmf
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:	