.. automodule:: nimfa.models.nmf_ns
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:	