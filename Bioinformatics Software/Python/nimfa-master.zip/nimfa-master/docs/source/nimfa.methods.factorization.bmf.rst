.. automodule:: nimfa.methods.factorization.bmf
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance: