.. automodule:: nimfa.models.nmf_std
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:	