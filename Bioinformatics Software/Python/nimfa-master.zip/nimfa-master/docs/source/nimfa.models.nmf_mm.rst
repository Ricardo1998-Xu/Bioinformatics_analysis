.. automodule:: nimfa.models.nmf_mm
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:	