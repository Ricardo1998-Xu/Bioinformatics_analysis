.. automodule:: nimfa.methods.factorization.bd
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance: