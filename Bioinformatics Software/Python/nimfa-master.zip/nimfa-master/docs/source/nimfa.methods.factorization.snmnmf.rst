.. automodule:: nimfa.methods.factorization.snmnmf
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:	