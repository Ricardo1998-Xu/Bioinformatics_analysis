
 * Distance
 
 * Residuals
 
 * Connectivity matrix
 
 * Consensus matrix
 
 * Entropy of the fitted NMF model [Park2007]_
 
 * Dominant basis components computation
 
 * Explained variance
 
 * Feature score computation representing its specificity to basis vectors [Park2007]_
 
 * Computation of most basis specific features for basis vectors [Park2007]_
 
 * Purity [Park2007]_
 
 * Residual sum of squares (rank estimation) [Hutchins2008]_, [Frigyesi2008]_
 
 * Sparseness [Hoyer2004]_
 
 * Cophenetic correlation coefficient of consensus matrix (rank estimation) [Brunet2004]_
 
 * Dispersion [Park2007]_
 
 * Factorization rank estimation
 
 * Selected matrix factorization method specific
