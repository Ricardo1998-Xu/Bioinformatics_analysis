#################
Utils (``utils``)
#################
    
.. automodule:: nimfa.utils
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:	


.. toctree::
   :maxdepth: 2

   nimfa.utils.utils
   
   nimfa.utils.linalg
   

