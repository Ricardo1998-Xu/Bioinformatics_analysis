.. automodule:: nimfa.methods.seeding.nndsvd
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:	