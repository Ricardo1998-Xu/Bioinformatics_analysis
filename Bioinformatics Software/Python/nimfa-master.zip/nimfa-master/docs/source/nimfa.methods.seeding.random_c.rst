.. automodule:: nimfa.methods.seeding.random_c
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:	