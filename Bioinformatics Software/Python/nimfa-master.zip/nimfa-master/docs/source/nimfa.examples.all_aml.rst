.. automodule:: nimfa.examples.all_aml
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:
	
.. comment literalinclude:: ../../nimfa/examples/all_aml.py
	:lines: 106-209
	:linenos:
