.. automodule:: nimfa.methods.seeding.random_vcol
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:	