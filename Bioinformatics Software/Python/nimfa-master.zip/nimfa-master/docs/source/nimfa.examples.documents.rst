.. automodule:: nimfa.examples.documents
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:
	
.. comment literalinclude:: ../../nimfa/examples/documents.py
	:lines: 99-262
	:linenos:
