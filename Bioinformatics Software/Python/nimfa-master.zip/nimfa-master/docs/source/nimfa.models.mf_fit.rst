.. automodule:: nimfa.models.mf_fit
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:	