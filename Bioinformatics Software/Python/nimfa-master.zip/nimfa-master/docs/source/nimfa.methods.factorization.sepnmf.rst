.. automodule:: nimfa.methods.factorization.sepnmf
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:
