.. automodule:: nimfa.examples.synthetic
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:
	
.. comment literalinclude:: ../../nimfa/examples/synthetic.py
	:lines: 35-378
	:linenos:
