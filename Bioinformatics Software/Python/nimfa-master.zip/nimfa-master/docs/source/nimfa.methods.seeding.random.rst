.. automodule:: nimfa.methods.seeding.random
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:	