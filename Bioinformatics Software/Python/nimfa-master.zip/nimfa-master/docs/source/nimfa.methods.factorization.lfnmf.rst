.. automodule:: nimfa.methods.factorization.lfnmf
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance: