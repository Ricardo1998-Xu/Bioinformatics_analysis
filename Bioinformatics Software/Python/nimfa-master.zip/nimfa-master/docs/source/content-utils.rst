
 * Fitted factorization model tracker across multiple runs
 
 * Residuals tracker across multiple factorizations / runs