.. automodule:: nimfa.methods.seeding.fixed
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:	