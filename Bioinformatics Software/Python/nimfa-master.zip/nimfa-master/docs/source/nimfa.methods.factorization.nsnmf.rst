.. automodule:: nimfa.methods.factorization.nsnmf
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance: