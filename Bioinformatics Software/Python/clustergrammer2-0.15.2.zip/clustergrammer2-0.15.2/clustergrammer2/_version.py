#!/usr/bin/env python
# coding: utf-8

# Copyright (c) Nicolas Fernandez.
# Distributed under the terms of the Modified BSD License.

version_info = (0, 15, 2)
__version__ = ".".join(map(str, version_info))
