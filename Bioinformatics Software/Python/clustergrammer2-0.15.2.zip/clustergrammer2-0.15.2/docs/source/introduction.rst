=============
Introduction
=============

.. todo::

    add prose explaining project purpose and usage here
