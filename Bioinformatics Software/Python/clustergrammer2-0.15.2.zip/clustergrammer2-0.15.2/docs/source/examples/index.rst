
Examples
========

This section contains several examples generated from Jupyter notebooks.
The widgets have been embedded into the page for demonstrative pruposes.

.. todo::

    Add links to notebooks in examples folder similar to the initial
    one. This is a manual step to ensure only those examples that
    are suited for inclusion are used.


.. toctree::
    :glob:

    *
