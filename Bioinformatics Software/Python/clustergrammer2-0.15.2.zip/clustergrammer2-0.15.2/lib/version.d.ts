/**
 * The current package version.
 */
export declare const MODULE_VERSION: any;
export declare const MODULE_NAME: any;
