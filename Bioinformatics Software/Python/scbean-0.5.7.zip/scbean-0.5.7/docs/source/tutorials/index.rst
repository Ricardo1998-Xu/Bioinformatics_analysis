Tutorials for scbean--DAVAE
=========================================================
.. toctree::
   :maxdepth: 2

   davae_mcl_tutorial
   davae_spatial


Tutorials for scbean--VIPCCA
=========================================================

.. toctree::
   :maxdepth: 2

   vipcca_mcl_tutorial
   R_analyses
   vipcca_atac_tutorial


Tutorials for scbean--VIMCCA
=========================================================

.. toctree::
   :maxdepth: 2

   vimcca_atac_rna_tutorial
   vimcca_protein_rna_tutorial
   vimcca_bmcite_rna_protein_tutorial


Tutorials for scbean--VISGP
=========================================================

.. toctree::
   :maxdepth: 2

   visgp_tutorial
   visgp_R_analysis


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
