from kb_python.logging import logger
logger.setLevel(9999)
