import ngs_tools as ngs

logger = ngs.logging.Logger(__name__)
ngs.logging.set_logger(logger)
