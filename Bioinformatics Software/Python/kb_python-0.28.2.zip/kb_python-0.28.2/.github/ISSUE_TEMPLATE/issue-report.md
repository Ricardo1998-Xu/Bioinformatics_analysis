---
name: Issue report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Describe the issue**
A clear and concise description of what the issue is.


**What is the exact command that was run?**
```
kb count ...
```

**Command output (with `--verbose` flag)**
```
Please copy and paste *VERBOSE* output here.
```
