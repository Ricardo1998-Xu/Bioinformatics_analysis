if PY3:
    exec_ = eval("exec")
