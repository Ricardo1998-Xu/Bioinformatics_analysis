from mpmath.libmp import *
from mpmath import *
import random
