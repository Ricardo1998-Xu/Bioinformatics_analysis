import calculus
# XXX: hack to set methods
import approximation
import differentiation
import extrapolation
import polynomials
