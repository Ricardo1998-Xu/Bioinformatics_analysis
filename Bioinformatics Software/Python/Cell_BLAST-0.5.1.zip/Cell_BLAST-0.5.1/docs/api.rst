API Documentation
=================

This section provides detailed API documentation for all public functions
and methods in ``Cell_BLAST``.

.. toctree::
   :maxdepth: 2

   modules/Cell_BLAST.data
   modules/Cell_BLAST.directi
   modules/Cell_BLAST.latent
   modules/Cell_BLAST.prob
   modules/Cell_BLAST.rmbatch
   modules/Cell_BLAST.blast
