Module: ``Cell_BLAST.prob``
===========================

.. automodule:: Cell_BLAST.prob
    :members:
