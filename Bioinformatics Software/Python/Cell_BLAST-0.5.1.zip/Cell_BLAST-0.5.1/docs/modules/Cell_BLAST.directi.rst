Module: ``Cell_BLAST.directi``
==============================

.. automodule:: Cell_BLAST.directi
    :members:
