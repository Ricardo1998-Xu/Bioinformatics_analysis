Module: ``Cell_BLAST.latent``
=============================

.. automodule:: Cell_BLAST.latent
    :members:
