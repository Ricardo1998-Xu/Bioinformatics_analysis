# README.md

The following packages are required to build the documentation:

* sphinx
* numpydoc

To build, simply run:

```
make html
```
