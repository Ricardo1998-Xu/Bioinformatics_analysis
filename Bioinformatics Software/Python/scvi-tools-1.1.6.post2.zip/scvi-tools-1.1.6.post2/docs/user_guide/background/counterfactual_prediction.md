# Counterfactual prediction

:::{note}
This page is under construction.
:::
