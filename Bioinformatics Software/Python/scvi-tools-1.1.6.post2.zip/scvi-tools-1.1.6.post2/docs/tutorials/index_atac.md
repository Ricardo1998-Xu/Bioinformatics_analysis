# ATAC-seq

```{toctree}
:maxdepth: 1

notebooks/atac/PeakVI
notebooks/atac/peakvi_in_R
notebooks/atac/scbasset
notebooks/atac/scbasset_batch
notebooks/atac/PoissonVI
```
