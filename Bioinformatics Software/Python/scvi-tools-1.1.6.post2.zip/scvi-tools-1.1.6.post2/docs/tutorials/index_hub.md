# Model hub

```{toctree}
:maxdepth: 1

notebooks/hub/scvi_hub_intro_and_download
notebooks/hub/scvi_hub_upload_and_large_files
notebooks/hub/minification
```
