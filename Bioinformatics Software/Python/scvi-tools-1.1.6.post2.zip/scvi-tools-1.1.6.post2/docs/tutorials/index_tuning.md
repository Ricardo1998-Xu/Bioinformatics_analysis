# Hyperparameter tuning

```{toctree}
:maxdepth: 1

notebooks/tuning/autotune_scvi
notebooks/tuning/autotune_new_model
```
