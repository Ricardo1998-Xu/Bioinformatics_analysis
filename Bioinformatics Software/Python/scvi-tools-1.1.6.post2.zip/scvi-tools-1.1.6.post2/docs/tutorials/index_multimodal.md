# Multimodal

```{toctree}
:maxdepth: 1

notebooks/multimodal/totalVI
notebooks/multimodal/cite_scrna_integration_w_totalVI
notebooks/multimodal/totalVI_reference_mapping
notebooks/multimodal/totalvi_in_R
notebooks/multimodal/MultiVI_tutorial
```
