---
name: Bug report
about: Create a report to help us improve
title: ""
labels: bug
assignees: ""
---

<!-- Describe the bug -->

[TEXT HERE]

<!-- To reproduce -->

```python
# Your code here
```

<!-- Put your Error output in this code block (if applicable, else delete the block): -->

```pytb
[Paste the error output produced by the above code here]
```

#### Versions:

<!-- Output of scvi.__version__ -->

> VERSION

<!-- Relevant screenshots -->
