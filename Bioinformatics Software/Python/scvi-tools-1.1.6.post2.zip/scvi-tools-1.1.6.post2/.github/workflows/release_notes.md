See the [release notes](https://docs.scvi-tools.org/en/stable/release_notes/index.html) for all changes.

This release is available via PyPi:

```bash
pip install scvi-tools
```

Conda availability will follow (< 2 days typically)

Please report any issues on [GitHub](https://github.com/scverse/scvi-tools).
