from ._plotting import plot_gene_patterns, plot_mapped_cells, plot_histogram_intestine, \
    plot_dendrogram, plot_archetypes, plot_spatial_expression_intestine, plot_transport_entropy_dist, \
    embedding, plot_morans_dists, plot_exp_loc_dists
