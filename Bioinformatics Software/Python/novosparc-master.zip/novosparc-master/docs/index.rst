.. novosparc documentation master file, created by
   sphinx-quickstart on Fri Feb  8 11:23:52 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: ../README.rst
   :end-line: 32

.. include:: release_notes.rst

.. toctree::
   :maxdepth: 1
   :hidden:

   installation
   tutorials
   references
