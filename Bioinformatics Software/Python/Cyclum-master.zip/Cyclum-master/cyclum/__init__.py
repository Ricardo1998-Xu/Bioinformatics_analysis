"""Top-level package for cyclum."""

__author__ = "Shaoheng Liang"
__email__ = "sliang3@mdanderson.org"
__version__ = "0.1"