============
Installation
============

At the command line::

    $ easy_install outrigger

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv outrigger
    $ pip install outrigger
