v0.3.0 (...)
------------

This is the second release of `outrigger`

New features
~~~~~~~~~~~~

- Parallelized exon finding for novel exons
- Added ``outrigger validate`` command for

Plotting functions
~~~~~~~~~~~~~~~~~~

API changes
~~~~~~~~~~~


Bug fixes
~~~~~~~~~

Miscellaneous
~~~~~~~~~~~~~

