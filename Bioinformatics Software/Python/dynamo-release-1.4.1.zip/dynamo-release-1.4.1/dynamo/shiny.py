"""Shiny interactive web application."""

from .shiny import *
