# -*- coding: utf-8 -*-

"""Dynamo test package initialization."""

__version__ = "0.0.0"
