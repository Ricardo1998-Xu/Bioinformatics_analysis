.. CellCnn documentation master file, created by
   sphinx-quickstart on Mon Feb 13 21:46:49 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to CellCnn's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   code.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
