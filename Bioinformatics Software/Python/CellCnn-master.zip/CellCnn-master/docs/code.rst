Documentation
*************

model
=====

.. automodule:: cellCnn.model

.. autoclass:: cellCnn.model.CellCnn
   :members: fit, predict

plotting
========

.. automodule:: cellCnn.plotting
   :members: plot_results
