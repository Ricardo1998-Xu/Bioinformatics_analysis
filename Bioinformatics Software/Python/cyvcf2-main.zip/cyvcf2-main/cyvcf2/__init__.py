from .cyvcf2 import (VCF, Variant, Writer, r_ as r_unphased, par_relatedness,
                     par_het)
Reader = VCFReader = VCF

__version__ = "0.31.1"
