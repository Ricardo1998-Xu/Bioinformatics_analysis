.. _api:

cyvcf2 API
==========

.. autoclass:: cyvcf2.cyvcf2.VCF
    :members:
    :no-undoc-members:
    :exclude-members: het_check,ibd,next,plot_relatedness,set_threads,site_relatedness,update
    
.. autoclass:: cyvcf2.cyvcf2.Variant
    :members:
    :exclude-members: relatedness

.. autoclass:: cyvcf2.cyvcf2.Writer
    :members:
    :no-undoc-members:

.. autoclass:: cyvcf2.cyvcf2.INFO
    :no-undoc-members:
