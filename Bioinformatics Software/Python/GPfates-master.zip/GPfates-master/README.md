# GPfates

Model transcriptional cell fates as mixtures of Gaussian Processes
