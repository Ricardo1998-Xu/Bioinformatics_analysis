Welcome to schist's documentation!
**********************************

.. toctree::
   :maxdepth: 1
   :caption: Contents:
   
   readme
   tutorials
   release_notes
   
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

schist has its documentation hosted on Read the Docs.
