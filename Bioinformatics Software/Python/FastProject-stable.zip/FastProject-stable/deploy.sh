python setup.py sdist --formats=gztar upload
