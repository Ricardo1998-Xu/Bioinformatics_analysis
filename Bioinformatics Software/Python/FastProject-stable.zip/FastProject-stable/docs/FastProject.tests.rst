FastProject.tests package
=========================

Submodules
----------

.. toctree::

   FastProject.tests.test_projections
   FastProject.tests.test_split_merge

Module contents
---------------

.. automodule:: FastProject.tests
    :members:
    :undoc-members:
    :show-inheritance:
