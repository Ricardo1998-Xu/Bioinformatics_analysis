FastProject.tests.test_split_merge module
=========================================

.. automodule:: FastProject.tests.test_split_merge
    :members:
    :undoc-members:
    :show-inheritance:
