FastProject.NormalizationMethods module
=======================================

.. automodule:: FastProject.NormalizationMethods
    :members:
    :undoc-members:
    :show-inheritance:
