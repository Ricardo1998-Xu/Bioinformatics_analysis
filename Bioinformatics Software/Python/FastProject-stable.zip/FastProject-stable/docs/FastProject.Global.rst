FastProject.Global module
=========================

.. automodule:: FastProject.Global
    :members:
    :undoc-members:
    :show-inheritance:
