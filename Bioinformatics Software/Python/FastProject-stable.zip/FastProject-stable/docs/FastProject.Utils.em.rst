FastProject.Utils.em module
===========================

.. automodule:: FastProject.Utils.em
    :members:
    :undoc-members:
    :show-inheritance:
