FastProject.DataTypes module
============================

.. automodule:: FastProject.DataTypes
    :members:
    :undoc-members:
    :show-inheritance:
