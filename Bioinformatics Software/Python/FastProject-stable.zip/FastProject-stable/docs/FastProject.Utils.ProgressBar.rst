FastProject.Utils.ProgressBar module
====================================

.. automodule:: FastProject.Utils.ProgressBar
    :members:
    :undoc-members:
    :show-inheritance:
