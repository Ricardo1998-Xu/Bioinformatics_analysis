FastProject.Projections module
==============================

.. automodule:: FastProject.Projections
    :members:
    :undoc-members:
    :show-inheritance:
