FastProject.SigScoreMethods module
==================================

.. automodule:: FastProject.SigScoreMethods
    :members:
    :undoc-members:
    :show-inheritance:
