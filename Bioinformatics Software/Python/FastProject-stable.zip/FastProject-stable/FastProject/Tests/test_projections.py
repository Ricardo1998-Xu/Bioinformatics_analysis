import unittest;


class TestProjectionMethods(unittest.TestCase):
    pass;
