# Store the version here to be imported by both the
# setup.py file and the package's init module

__version__ = "1.1.4";
