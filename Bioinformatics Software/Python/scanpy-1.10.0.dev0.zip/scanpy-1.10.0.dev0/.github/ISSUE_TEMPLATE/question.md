---
name: Design Question
about: Ask about Scanpy’s design. ⚠ not for help, see ↓ for that ⚠
title: ''
labels: question
assignees: ''
---

<!--
⚠ If you need help using Scanpy, please ask in https://discourse.scverse.org/ instead ⚠
If you want to know about design decisions and the like, please ask below:
-->
...
