from .cli import console_main

console_main()
