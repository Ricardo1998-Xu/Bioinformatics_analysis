# Contributors

```{eval-rst}
.. include::  _key_contributors.rst
```

## Current developers

## Other roles

## Former developers

- Tom White: developer 2018-2019, distributed computing
