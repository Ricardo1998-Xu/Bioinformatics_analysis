# Community

Scanpy is a community driven project. There are multiple channels for users and developers to communicate and connect.

## [Discourse](https://discourse.scverse.org)

The scverse Discourse forum is place to go to ask usage questions and for longer form discussions around the project.

## [Github Issue Tracker](https://github.com/theislab/scanpy/issues)

The [Scanpy](https://github.com/theislab/scanpy/issues) and [anndata](https://github.com/theislab/anndata/issues) issue trackers are for reports and discussion of:

- Bug reports
- Documentation issues
- Feature requests

## [Developer Chat](https://scverse.zulipchat.com/)

Zulip chat instance for synchronous discussion of scanpy, anndata, and other scverse packages.
