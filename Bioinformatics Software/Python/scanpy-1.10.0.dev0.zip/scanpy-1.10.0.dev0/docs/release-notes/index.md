(release-notes)=

# Release notes

```{include} release-latest.md
```

## Version 1.8

```{include} /release-notes/1.8.2.md
```

```{include} /release-notes/1.8.1.md
```

```{include} /release-notes/1.8.0.md
```

## Version 1.7

```{include} /release-notes/1.7.2.md
```

```{include} /release-notes/1.7.1.md
```

```{include} /release-notes/1.7.0.md
```

## Version 1.6

```{include} 1.6.0.md
```

## Version 1.5

```{include} 1.5.1.md
```

```{include} 1.5.0.md
```

## Version 1.4

```{include} 1.4.6.md
```

```{include} 1.4.5.md
```

```{include} 1.4.4.md
```

```{include} 1.4.3.md
```

```{include} 1.4.2.md
```

```{include} 1.4.1.md
```

## Version 1.3

```{include} 1.3.8.md
```

```{include} 1.3.7.md
```

```{include} 1.3.6.md
```

```{include} 1.3.5.md
```

```{include} 1.3.4.md
```

```{include} 1.3.3.md
```

```{include} 1.3.1.md
```

## Version 1.2

```{include} 1.2.1.md
```

```{include} 1.2.0.md
```

## Version 1.1

```{include} 1.1.0.md
```

## Version 1.0

```{include} 1.0.0.md
```

## Version 0.4

```{include} 0.4.4.md
```

```{include} 0.4.3.md
```

```{include} 0.4.2.md
```

```{include} 0.4.0.md
```

## Version 0.3

```{include} 0.3.2.md
```

```{include} 0.3.0.md
```

## Version 0.2

```{include} 0.2.9.md
```

```{include} 0.2.1.md
```

## Version 0.1

```{include} 0.1.0.md
```
